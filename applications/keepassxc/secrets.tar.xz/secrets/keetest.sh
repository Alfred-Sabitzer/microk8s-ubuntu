
#!/bin/bash
############################################################################################
#
# Assumption: OpenBao is already installed and running in the cluster, and the openbao-0 pod is available.
# Kubernetes engine enabled, structure prepared
#
# This script will:
# 1. Create a policy that allows read access to the k8s/*keetest
# 2. Create a role that uses the policy
#
# https://github.com/openbao/openbao-csi-provider/tree/main/test/bats
#
# Structure:
#
# One secret-path per Namespace, and one Role per Namespace. This allows for better organization and management of secrets.
# One Policy per Role, and one Role per Service Account. This allows for better management and auditing of permissions.
# One Service Account per Role. This allows for better isolation and security.
#
############################################################################################
shopt -o -s errexit    #—Terminates  the shell script  if a command returns an error code.
#shopt -o -s xtrace #—Displays each command before it is executed.
shopt -o -s nounset #-No Variables without definition
set -euo pipefail

openbaospace="openbao"
kubectl="sudo microk8s kubectl"

if [ -z "${OPENBAO_ROOT_TOKEN:-}" ]; then
  echo "Error: OPENBAO_ROOT_TOKEN must be set" >&2
  exit 1
fi

if ! ${kubectl} -n "${openbaospace}" get pod openbao-0 >/dev/null 2>&1; then
  echo "Error: OpenBao pod openbao-0 not found in namespace ${openbaospace}" >&2
  exit 1
fi

# Login
roottoken="${OPENBAO_ROOT_TOKEN}"
echo "${roottoken}" | ${kubectl} --namespace="${openbaospace}" exec -i openbao-0 -- bao login -

# Create Policy
echo "Creating policy for secretspace keetest..."
cat <<EOF | ${kubectl} --namespace="${openbaospace}" exec -i openbao-0 -- bao policy write keetest -
# SPDX-License-Identifier: MPL-2.0
# Source and License see: https://github.com/Alfred-Sabitzer/microk8s-ubuntu/tree/main/applications/keepassxc
# Created on 2026-06-16 15:59:06
path "secret/data/keetest/*" {
  capabilities = ["read"]
}
EOF

# Configure roles
echo "Configuring role for secretspace keetest..."
${kubectl} --namespace=${openbaospace} exec openbao-0 -- bao write auth/kubernetes/role/keetest-role \
    bound_service_account_names=keetest-sa \
    bound_service_account_namespaces=keetest \
    audience="https://kubernetes.default.svc" \
    policies=keetest \
    ttl=20m

echo "Activating secrets engine and creating secret for secretspace keetest"
${kubectl} --namespace=${openbaospace} exec -i openbao-0 -- bao kv delete -mount=secret keetest || true
echo "Create secret for secretspace keetest"
${kubectl} --namespace="${openbaospace}" exec -i openbao-0 -- bao kv put secret/keetest/ob-basicauth  username="alfred" password="VvFkZG8vo7pzoSCfCh7HZVboWlVrnWJD" 
${kubectl} --namespace="${openbaospace}" exec -i openbao-0 -- bao kv put secret/keetest/ob-docker  .dockerconfigjson="{"auths": {"docker.com": {"username": "docker", "password": "ZtRbXa4zvqrOn78YUVMUTJLx7W0DCIOO", "email": "docker@slainte.at", "auth": "ZG9ja2VyOlp0UmJYYTR6dnFyT243OFlVVk1VVEpMeDdXMERDSU9P"}}}" 
${kubectl} --namespace="${openbaospace}" exec -i openbao-0 -- bao kv put secret/keetest/ob-k8ssecret  username="alfred" password="VvFkZG8vo7pzoSCfCh7HZVboWlVrnWJD" url="https://slainte.at" notes="Test for standard K8s-secret" 
${kubectl} --namespace="${openbaospace}" exec -i openbao-0 -- bao kv put secret/keetest/ob-k8ssimple  username="alfred" password="VvFkZG8vo7pzoSCfCh7HZVboWlVrnWJD" 
${kubectl} --namespace="${openbaospace}" exec -i openbao-0 -- bao kv put secret/keetest/ob-ssh  ssh-publickey="ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAII2g9/RtxWl/+uk+NekK5TFEQw5RdYe5dxqnfu4HA0YK alfred@alfred-VirtualBox" ssh-privatekey="-----BEGIN OPENSSH PRIVATE KEY-----
b3BlbnNzaC1rZXktdjEAAAAABG5vbmUAAAAEbm9uZQAAAAAAAAABAAAAMwAAAAtzc2gtZW
QyNTUxOQAAACCNoPf0bcVpf/rpPjXpCuUxREMOUXWHuXcap37uBwNGCgAAAKCdI2TAnSNk
wAAAAAtzc2gtZWQyNTUxOQAAACCNoPf0bcVpf/rpPjXpCuUxREMOUXWHuXcap37uBwNGCg
AAAEANcktMWe7eS5VLMVyoeWhShItByt8YGF0UHNJ1P4WXt42g9/RtxWl/+uk+NekK5TFE
Qw5RdYe5dxqnfu4HA0YKAAAAGGFsZnJlZEBhbGZyZWQtVmlydHVhbEJveAECAwQF
-----END OPENSSH PRIVATE KEY-----" 
${kubectl} --namespace="${openbaospace}" exec -i openbao-0 -- bao kv put secret/keetest/ob-tls  tls.crt="ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABgQCxRF29WfZ8tpXzqi1/nq9+5w2KoAr0CtsUJ3OwxMHTvU6p0YGcXFgLeGAnlyNkdqOhAr2jTo9fa4AWALIYX9c5slIl5f1POLaqFDXCY9SCGsOOCOEsFff4DJeDKoKt+e4ARkrhwY66jdUc3XydMweZItVB2WqZfnuCMA1ziH9sU07NQI16TApgzrPrspqvchHpD1i4I/JZMZPZGi6RUO/RJ3afxJ9iICRIecuYU7h/z3/ZucbSt1L4r/08imiwouvqoS3hL+fwjlQSmdDxlVQdPT2TLV0Nl3wG3Oq0hCyu26AgRfjnHZHQHVmgJyrFwSdYaZdV5GXU/vh0a13T5uKhCLNYpvAL6Lmg7yO7DCLUzD3W5r7P+IKJM59h9qdnEzN7VSOXPVZNlW7j/WbHWR9t3dQc5JROoZGKvmcIedE7jaX3WUCJNVAPqZ7saQC6VZL/9Dme3gtePkAgmx6K4QURKNgF5pD3Qp8lmpGdrQ70WjkLcmejnaY47qIM1yjq3iU= root@alfred-VirtualBox" tls.key="-----BEGIN OPENSSH PRIVATE KEY-----
b3BlbnNzaC1rZXktdjEAAAAABG5vbmUAAAAEbm9uZQAAAAAAAAABAAABlwAAAAdzc2gtcn
NhAAAAAwEAAQAAAYEAsURdvVn2fLaV86otf56vfucNiqAK9ArbFCdzsMTB071OqdGBnFxY
C3hgJ5cjZHajoQK9o06PX2uAFgCyGF/XObJSJeX9Tzi2qhQ1wmPUghrDjgjhLBX3+AyXgy
qCrfnuAEZK4cGOuo3VHN18nTMHmSLVQdlqmX57gjANc4h/bFNOzUCNekwKYM6z67Kar3IR
6Q9YuCPyWTGT2RoukVDv0Sd2n8SfYiAkSHnLmFO4f89/2bnG0rdS+K/9PIposKLr6qEt4S
/n8I5UEpnQ8ZVUHT09ky1dDZd8BtzqtIQsrtugIEX45x2R0B1ZoCcqxcEnWGmXVeRl1P74
dGtd0+bioQizWKbwC+i5oO8juwwi1Mw91ua+z/iCiTOfYfanZxMze1Ujlz1WTZVu4/1mx1
kfbd3UHOSUTqGRir5nCHnRO42l91lAiTVQD6me7GkAulWS//Q5nt4LXj5AIJseiuEFESjY
BeaQ90KfJZqRna0O9Fo5C3Jno52mOO6iDNco6t4lAAAFkOjinL3o4py9AAAAB3NzaC1yc2
EAAAGBALFEXb1Z9ny2lfOqLX+er37nDYqgCvQK2xQnc7DEwdO9TqnRgZxcWAt4YCeXI2R2
o6ECvaNOj19rgBYAshhf1zmyUiXl/U84tqoUNcJj1IIaw44I4SwV9/gMl4Mqgq357gBGSu
HBjrqN1RzdfJ0zB5ki1UHZapl+e4IwDXOIf2xTTs1AjXpMCmDOs+uymq9yEekPWLgj8lkx
k9kaLpFQ79Endp/En2IgJEh5y5hTuH/Pf9m5xtK3Uviv/TyKaLCi6+qhLeEv5/COVBKZ0P
GVVB09PZMtXQ2XfAbc6rSELK7boCBF+OcdkdAdWaAnKsXBJ1hpl1XkZdT++HRrXdPm4qEI
s1im8AvouaDvI7sMItTMPdbmvs/4gokzn2H2p2cTM3tVI5c9Vk2VbuP9ZsdZH23d1BzklE
6hkYq+Zwh50TuNpfdZQIk1UA+pnuxpALpVkv/0OZ7eC14+QCCbHorhBREo2AXmkPdCnyWa
kZ2tDvRaOQtyZ6OdpjjuogzXKOreJQAAAAMBAAEAAAGAAR8dZZKCf1427/KnngoEVzu0AL
riokjIujNF/FMcpfjy3NHDcj0GeUuIdn6EzeCzteYmU29lc4niyzezewuR5vV6OW9Nb6AX
4Fbi0sJjFAbLdzsWb+jBGhhOTNAT+Ew/cQclZWz5lEYnTxiogK3Twmh9OaM3cKgskE0WPm
oZdNvtN6MWIhCYGRKO3dv2yG/QiVZzTgipVPD+AIxsgEmU4JBjtj7r3c2RQcWPf/zd5ndm
Z+S+gjfJtj5fYJR3UKvs6njaYy5A50W3OzAKgE4BPLq0BzEB6/XlH2g1n3gePoGqBcpGpi
E78Zn49QEmjEws83AfTMSTy4UMopsiz1EKVSVo4TbjvWao35JH0YtBFgR0sUkYJu7RLNfy
VCxDBZnvUFK1wWUv+qAiBbX5TxW9jgVFj+K4hsJ6YlRsnkv6Z9FPoRthrQ3V2vYJpvnjxg
+HQCm9SJZ1Zzb7HFxTguFn5lD1JA/CJgLv2mTDjJUai1whJpcfhFZVCswaM8FG2PqhAAAA
wH4eUmk3WXsR8Llw4y2TDGQjq35W1Xg5SNcXhajCFWy+GvkhQ3rkTMJ6LvHsaP7k5AyXJN
EQAWcwQxnWg0OTlyr9rYetrj5JhTcep/aK4O9UNycVa0htOyp1LnPJrAvg4F1B0dSnn0Rb
cpL5h+3QPwkZWx8Yqx8bhAP6VBFLCTuolTCqLNBjaUmqAgbkOIQTChhPJyF0SOEkoqBJ6C
nx8RoIWMcLwpb+1VwAwwNlJA16wiV1OPE4MtN0CmLvVCI0bAAAAMEA8PwdTPcuGPaxFgL0
gEY+TtdnK3iqPZNzbHkDqbk9JPAB/mAbsoKeKar9dJ3TmnpiKxyUD6SDATUPC6QbTsCzP+
XbFZhOsmBiSLNcKcv7cvoUIma7fGN2/krZV/AkYrp+MY/1IrTGLWMT4lyLzLSax/bFQLJs
qACAE7hemKuk3txOqyD/7/LK/Lo9QKIj0poqEyvdvNsNjt9ftVYX0gYgCpytYSF/+fJrfl
dWx9ld9Or6rUdFkP3cZy5vTTFYvuC1AAAAwQC8T+gHw7iXZcHqj45kj3H2ei9gJI3gZtqv
WmcKxrPiABsvE2mtgt8zfGDycufCtbRZT7uA49rUU2hoyY+XiwmlpmxF2HWwExYnlaKLKf
rC/cfJW80nrX94Znv3Oh7oD6SXamAXQNiQq6vZizv2bDRbexgzS4XFrDmVCqbAUPsj70pA
LHq30Gaut8ot48VBEYVteOyBSIrpMk+mDLOZMsoIF0jAhtgQ+STaK37Mx8AO8EX+ZAtA49
IeTqQsaT6pHbEAAAAWcm9vdEBhbGZyZWQtVmlydHVhbEJveAECAwQF
-----END OPENSSH PRIVATE KEY-----
" ca.crt="ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABgQCxRF29WfZ8tpXzqi1/nq9+5w2KoAr0CtsUJ3OwxMHTvU6p0YGcXFgLeGAnlyNkdqOhAr2jTo9fa4AWALIYX9c5slIl5f1POLaqFDXCY9SCGsOOCOEsFff4DJeDKoKt+e4ARkrhwY66jdUc3XydMweZItVB2WqZfnuCMA1ziH9sU07NQI16TApgzrPrspqvchHpD1i4I/JZMZPZGi6RUO/RJ3afxJ9iICRIecuYU7h/z3/ZucbSt1L4r/08imiwouvqoS3hL+fwjlQSmdDxlVQdPT2TLV0Nl3wG3Oq0hCyu26AgRfjnHZHQHVmgJyrFwSdYaZdV5GXU/vh0a13T5uKhCLNYpvAL6Lmg7yO7DCLUzD3W5r7P+IKJM59h9qdnEzN7VSOXPVZNlW7j/WbHWR9t3dQc5JROoZGKvmcIedE7jaX3WUCJNVAPqZ7saQC6VZL/9Dme3gtePkAgmx6K4QURKNgF5pD3Qp8lmpGdrQ70WjkLcmejnaY47qIM1yjq3iU= root@alfred-VirtualBox" 
${kubectl} --namespace="${openbaospace}" exec -i openbao-0 -- bao kv put secret/keetest/obsync-k8ssecret  username="alfred" password="VvFkZG8vo7pzoSCfCh7HZVboWlVrnWJD" url="https://slainte.at" notes="Test for standard K8s-secret" 

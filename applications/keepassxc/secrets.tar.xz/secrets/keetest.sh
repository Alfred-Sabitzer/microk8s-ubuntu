#!/usr/bin/env bash
set -euo pipefail

openbaospace="openbao"
kubectl="sudo microk8s kubectl"

if [ -z "${OPENBAO_ROOT_TOKEN:-}" ]; then
  echo "Error: OPENBAO_ROOT_TOKEN must be set" >&2
  exit 1
fi

if ! ${kubectl} -n "${openbaospace}" get pod openbao-0 >/dev/null 2>&1; then
  echo "Error: OpenBao pod openbao-0 not found in namespace ${openbaospace}" >&2
  exit 1
fi

# Login
roottoken="${OPENBAO_ROOT_TOKEN}"
echo "${roottoken}" | ${kubectl} --namespace="${openbaospace}" exec -i openbao-0 -- bao login -

echo "Creating policy for secretspace keetest..."
cat <<EOF | ${kubectl} --namespace="${openbaospace}" exec -i openbao-0 -- bao policy write keetest -
# SPDX-License-Identifier: MPL-2.0
# Source and License see: https://github.com/Alfred-Sabitzer/microk8s-ubuntu/tree/main/applications/keepassxc
# Created on 2026-06-28 06:29:52
path "secret/data/keetest/*" {
  capabilities = ["read"]
}
EOF

echo "Configuring role for secretspace keetest..."
${kubectl} --namespace=${openbaospace} exec openbao-0 -- bao write auth/kubernetes/role/keetest-role \
    bound_service_account_names=keetest-sa \
    bound_service_account_namespaces=keetest \
    audience="https://kubernetes.default.svc" \
    policies=keetest \
    ttl=20m

echo "Activating secrets engine and creating secret for secretspace keetest"
${kubectl} --namespace=${openbaospace} exec -i openbao-0 -- bao kv delete -mount=secret keetest || true
echo "Create secret for secretspace keetest"
${kubectl} --namespace="${openbaospace}" exec -i openbao-0 -- bao kv delete secret/keetest/ob-basicauth || true
${kubectl} --namespace="${openbaospace}" exec -i openbao-0 -- bao kv put secret/keetest/ob-basicauth  username="$(echo 'YWxmcmVk' | base64 --decode)" password="$(echo 'VnZGa1pHOHZvN3B6b1NDZkNoN0haVmJvV2xWcm5XSkQ=' | base64 --decode)"
${kubectl} --namespace="${openbaospace}" exec -i openbao-0 -- bao kv delete secret/keetest/ob-docker || true
${kubectl} --namespace="${openbaospace}" exec -i openbao-0 -- bao kv put secret/keetest/ob-docker  .dockerconfigjson="$(echo 'eyJhdXRocyI6IHsiZG9ja2VyLmNvbSI6IHsidXNlcm5hbWUiOiAiZG9ja2VyIiwgInBhc3N3b3JkIjogIlp0UmJYYTR6dnFyT243OFlVVk1VVEpMeDdXMERDSU9PIiwgImVtYWlsIjogImRvY2tlckBzbGFpbnRlLmF0IiwgImF1dGgiOiAiWkc5amEyVnlPbHAwVW1KWVlUUjZkbkZ5VDI0M09GbFZWazFWVkVwTWVEZFhNRVJEU1U5UCJ9fX0=' | base64 --decode)"
${kubectl} --namespace="${openbaospace}" exec -i openbao-0 -- bao kv delete secret/keetest/ob-k8ssecret || true
${kubectl} --namespace="${openbaospace}" exec -i openbao-0 -- bao kv put secret/keetest/ob-k8ssecret  username="$(echo 'YWxmcmVk' | base64 --decode)" password="$(echo 'VnZGa1pHOHZvN3B6b1NDZkNoN0haVmJvV2xWcm5XSkQ=' | base64 --decode)" url="$(echo 'aHR0cHM6Ly9zbGFpbnRlLmF0' | base64 --decode)" notes="$(echo 'VGVzdCBmb3Igc3RhbmRhcmQgSzhzLXNlY3JldA==' | base64 --decode)"
${kubectl} --namespace="${openbaospace}" exec -i openbao-0 -- bao kv delete secret/keetest/ob-k8ssimple || true
${kubectl} --namespace="${openbaospace}" exec -i openbao-0 -- bao kv put secret/keetest/ob-k8ssimple  username="$(echo 'YWxmcmVk' | base64 --decode)" password="$(echo 'VnZGa1pHOHZvN3B6b1NDZkNoN0haVmJvV2xWcm5XSkQ=' | base64 --decode)"
${kubectl} --namespace="${openbaospace}" exec -i openbao-0 -- bao kv delete secret/keetest/ob-ssh || true
${kubectl} --namespace="${openbaospace}" exec -i openbao-0 -- bao kv put secret/keetest/ob-ssh  ssh-publickey="$(echo 'c3NoLWVkMjU1MTkgQUFBQUMzTnphQzFsWkRJMU5URTVBQUFBSUkyZzkvUnR4V2wvK3VrK05la0s1VEZFUXc1UmRZZTVkeHFuZnU0SEEwWUsgYWxmcmVkQGFsZnJlZC1WaXJ0dWFsQm94' | base64 --decode)" ssh-privatekey="$(echo 'LS0tLS1CRUdJTiBPUEVOU1NIIFBSSVZBVEUgS0VZLS0tLS0KYjNCbGJuTnphQzFyWlhrdGRqRUFBQUFBQkc1dmJtVUFBQUFFYm05dVpRQUFBQUFBQUFBQkFBQUFNd0FBQUF0emMyZ3RaVwpReU5UVXhPUUFBQUNDTm9QZjBiY1ZwZi9ycFBqWHBDdVV4UkVNT1VYV0h1WGNhcDM3dUJ3TkdDZ0FBQUtDZEkyVEFuU05rCndBQUFBQXR6YzJndFpXUXlOVFV4T1FBQUFDQ05vUGYwYmNWcGYvcnBQalhwQ3VVeFJFTU9VWFdIdVhjYXAzN3VCd05HQ2cKQUFBRUFOY2t0TVdlN2VTNVZMTVZ5b2VXaFNoSXRCeXQ4WUdGMFVITkoxUDRXWHQ0Mmc5L1J0eFdsLyt1aytOZWtLNVRGRQpRdzVSZFllNWR4cW5mdTRIQTBZS0FBQUFHR0ZzWm5KbFpFQmhiR1p5WldRdFZtbHlkSFZoYkVKdmVBRUNBd1FGCi0tLS0tRU5EIE9QRU5TU0ggUFJJVkFURSBLRVktLS0tLQ==' | base64 --decode)"
${kubectl} --namespace="${openbaospace}" exec -i openbao-0 -- bao kv delete secret/keetest/ob-tls || true
${kubectl} --namespace="${openbaospace}" exec -i openbao-0 -- bao kv put secret/keetest/ob-tls  tls.crt="$(echo 'c3NoLXJzYSBBQUFBQjNOemFDMXljMkVBQUFBREFRQUJBQUFCZ1FDeFJGMjlXZlo4dHBYenFpMS9ucTkrNXcyS29BcjBDdHNVSjNPd3hNSFR2VTZwMFlHY1hGZ0xlR0FubHlOa2RxT2hBcjJqVG85ZmE0QVdBTElZWDljNXNsSWw1ZjFQT0xhcUZEWENZOVNDR3NPT0NPRXNGZmY0REplREtvS3QrZTRBUmtyaHdZNjZqZFVjM1h5ZE13ZVpJdFZCMldxWmZudUNNQTF6aUg5c1UwN05RSTE2VEFwZ3pyUHJzcHF2Y2hIcEQxaTRJL0paTVpQWkdpNlJVTy9SSjNhZnhKOWlJQ1JJZWN1WVU3aC96My9adWNiU3QxTDRyLzA4aW1pd291dnFvUzNoTCtmd2psUVNtZER4bFZRZFBUMlRMVjBObDN3RzNPcTBoQ3l1MjZBZ1Jmam5IWkhRSFZtZ0p5ckZ3U2RZYVpkVjVHWFUvdmgwYTEzVDV1S2hDTE5ZcHZBTDZMbWc3eU83RENMVXpEM1c1cjdQK0lLSk01OWg5cWRuRXpON1ZTT1hQVlpObFc3ai9XYkhXUjl0M2RRYzVKUk9vWkdLdm1jSWVkRTdqYVgzV1VDSk5WQVBxWjdzYVFDNlZaTC85RG1lM2d0ZVBrQWdteDZLNFFVUktOZ0Y1cEQzUXA4bG1wR2RyUTcwV2prTGNtZWpuYVk0N3FJTTF5anEzaVU9IHJvb3RAYWxmcmVkLVZpcnR1YWxCb3g=' | base64 --decode)" tls.key="$(echo 'LS0tLS1CRUdJTiBPUEVOU1NIIFBSSVZBVEUgS0VZLS0tLS0KYjNCbGJuTnphQzFyWlhrdGRqRUFBQUFBQkc1dmJtVUFBQUFFYm05dVpRQUFBQUFBQUFBQkFBQUJsd0FBQUFkemMyZ3RjbgpOaEFBQUFBd0VBQVFBQUFZRUFzVVJkdlZuMmZMYVY4Nm90ZjU2dmZ1Y05pcUFLOUFyYkZDZHpzTVRCMDcxT3FkR0JuRnhZCkMzaGdKNWNqWkhham9RSzlvMDZQWDJ1QUZnQ3lHRi9YT2JKU0plWDlUemkycWhRMXdtUFVnaHJEamdqaExCWDMrQXlYZ3kKcUNyZm51QUVaSzRjR091bzNWSE4xOG5UTUhtU0xWUWRscW1YNTdnakFOYzRoL2JGTk96VUNOZWt3S1lNNno2N0thcjNJUgo2UTlZdUNQeVdUR1QyUm91a1ZEdjBTZDJuOFNmWWlBa1NIbkxtRk80Zjg5LzJibkcwcmRTK0svOVBJcG9zS0xyNnFFdDRTCi9uOEk1VUVwblE4WlZVSFQwOWt5MWREWmQ4QnR6cXRJUXNydHVnSUVYNDV4MlIwQjFab0NjcXhjRW5XR21YVmVSbDFQNzQKZEd0ZDArYmlvUWl6V0tid0MraTVvTzhqdXd3aTFNdzkxdWErei9pQ2lUT2ZZZmFuWnhNemUxVWpsejFXVFpWdTQvMW14MQprZmJkM1VIT1NVVHFHUmlyNW5DSG5STzQybDkxbEFpVFZRRDZtZTdHa0F1bFdTLy9RNW50NExYajVBSUpzZWl1RUZFU2pZCkJlYVE5MEtmSlpxUm5hME85Rm81QzNKbm81Mm1PTzZpRE5jbzZ0NGxBQUFGa09qaW5MM280cHk5QUFBQUIzTnphQzF5YzIKRUFBQUdCQUxGRVhiMVo5bnkybGZPcUxYK2VyMzduRFlxZ0N2UUsyeFFuYzdERXdkTzlUcW5SZ1p4Y1dBdDRZQ2VYSTJSMgpvNkVDdmFOT2oxOXJnQllBc2hoZjF6bXlVaVhsL1U4NHRxb1VOY0pqMUlJYXc0NEk0U3dWOS9nTWw0TXFncTM1N2dCR1N1CkhCanJxTjFSemRmSjB6QjVraTFVSFphcGwrZTRJd0RYT0lmMnhUVHMxQWpYcE1DbURPcyt1eW1xOXlFZWtQV0xnajhsa3gKazlrYUxwRlE3OUVuZHAvRW4ySWdKRWg1eTVoVHVIL1BmOW01eHRLM1V2aXYvVHlLYUxDaTYrcWhMZUV2NS9DT1ZCS1owUApHVlZCMDlQWk10WFEyWGZBYmM2clNFTEs3Ym9DQkYrT2Nka2RBZFdhQW5Lc1hCSjFocGwxWGtaZFQrK0hSclhkUG00cUVJCnMxaW04QXZvdWFEdkk3c01JdFRNUGRibXZzLzRnb2t6bjJIMnAyY1RNM3RWSTVjOVZrMlZidVA5WnNkWkgyM2QxQnprbEUKNmhrWXErWndoNTBUdU5wZmRaUUlrMVVBK3BudXhwQUxwVmt2LzBPWjdlQzE0K1FDQ2JIb3JoQlJFbzJBWG1rUGRDbnlXYQprWjJ0RHZSYU9RdHlaNk9kcGpqdW9nelhLT3JlSlFBQUFBTUJBQUVBQUFHQUFSOGRaWktDZjE0MjcvS25uZ29FVnp1MEFMCnJpb2tqSXVqTkYvRk1jcGZqeTNOSERjajBHZVV1SWRuNkV6ZUN6dGVZbVUyOWxjNG5peXplemV3dVI1dlY2T1c5TmI2QVgKNEZiaTBzSmpGQWJMZHpzV2IrakJHaGhPVE5BVCtFdy9jUWNsWld6NWxFWW5UeGlvZ0szVHdtaDlPYU0zY0tnc2tFMFdQbQpvWmROdnRONk1XSWhDWUdSS08zZHYyeUcvUWlWWnpUZ2lwVlBEK0FJeHNnRW1VNEpCanRqN3IzYzJSUWNXUGYvemQ1bmRtClorUytnamZKdGo1ZllKUjNVS3ZzNm5qYVl5NUE1MFczT3pBS2dFNEJQTHEwQnpFQjYvWGxIMmcxbjNnZVBvR3FCY3BHcGkKRTc4Wm40OVFFbWpFd3M4M0FmVE1TVHk0VU1vcHNpejFFS1ZTVm80VGJqdldhbzM1SkgwWXRCRmdSMHNVa1lKdTdSTE5meQpWQ3hEQlpudlVGSzF3V1V2K3FBaUJiWDVUeFc5amdWRmorSzRoc0o2WWxSc25rdjZaOUZQb1J0aHJRM1YydllKcHZuanhnCitIUUNtOVNKWjFaemI3SEZ4VGd1Rm41bEQxSkEvQ0pnTHYybVREakpVYWkxd2hKcGNmaEZaVkNzd2FNOEZHMlBxaEFBQUEKd0g0ZVVtazNXWHNSOExsdzR5MlRER1FqcTM1VzFYZzVTTmNYaGFqQ0ZXeStHdmtoUTNya1RNSjZMdkhzYVA3azVBeVhKTgpFUUFXY3dReG5XZzBPVGx5cjlyWWV0cmo1SmhUY2VwL2FLNE85VU55Y1ZhMGh0T3lwMUxuUEpyQXZnNEYxQjBkU25uMFJiCmNwTDVoKzNRUHdrWld4OFlxeDhiaEFQNlZCRkxDVHVvbFRDcUxOQmphVW1xQWdia09JUVRDaGhQSnlGMFNPRWtvcUJKNkMKbng4Um9JV01jTHdwYisxVndBd3dObEpBMTZ3aVYxT1BFNE10TjBDbUx2VkNJMGJBQUFBTUVBOFB3ZFRQY3VHUGF4RmdMMApnRVkrVHRkbkszaXFQWk56YkhrRHFiazlKUEFCL21BYnNvS2VLYXI5ZEozVG1ucGlLeHlVRDZTREFUVVBDNlFiVHNDelArClhiRlpoT3NtQmlTTE5jS2N2N2N2b1VJbWE3ZkdOMi9rclpWL0FrWXJwK01ZLzFJclRHTFdNVDRseUx6TFNheC9iRlFMSnMKcUFDQUU3aGVtS3VrM3R4T3F5RC83L0xLL0xvOVFLSWowcG9xRXl2ZHZOc05qdDlmdFZZWDBnWWdDcHl0WVNGLytmSnJmbApkV3g5bGQ5T3I2clVkRmtQM2NaeTV2VFRGWXZ1QzFBQUFBd1FDOFQrZ0h3N2lYWmNIcWo0NWtqM0gyZWk5Z0pJM2dadHF2CldtY0t4clBpQUJzdkUybXRndDh6ZkdEeWN1ZkN0YlJaVDd1QTQ5clVVMmhveVkrWGl3bWxwbXhGMkhXd0V4WW5sYUtMS2YKckMvY2ZKVzgwbnJYOTRabnYzT2g3b0Q2U1hhbUFYUU5pUXE2dlppenYyYkRSYmV4Z3pTNFhGckRtVkNxYkFVUHNqNzBwQQpMSHEzMEdhdXQ4b3Q0OFZCRVlWdGVPeUJTSXJwTWsrbURMT1pNc29JRjBqQWh0Z1ErU1RhSzM3TXg4QU84RVgrWkF0QTQ5CkllVHFRc2FUNnBIYkVBQUFBV2NtOXZkRUJoYkdaeVpXUXRWbWx5ZEhWaGJFSnZlQUVDQXdRRgotLS0tLUVORCBPUEVOU1NIIFBSSVZBVEUgS0VZLS0tLS0K' | base64 --decode)" ca.crt="$(echo 'c3NoLXJzYSBBQUFBQjNOemFDMXljMkVBQUFBREFRQUJBQUFCZ1FDeFJGMjlXZlo4dHBYenFpMS9ucTkrNXcyS29BcjBDdHNVSjNPd3hNSFR2VTZwMFlHY1hGZ0xlR0FubHlOa2RxT2hBcjJqVG85ZmE0QVdBTElZWDljNXNsSWw1ZjFQT0xhcUZEWENZOVNDR3NPT0NPRXNGZmY0REplREtvS3QrZTRBUmtyaHdZNjZqZFVjM1h5ZE13ZVpJdFZCMldxWmZudUNNQTF6aUg5c1UwN05RSTE2VEFwZ3pyUHJzcHF2Y2hIcEQxaTRJL0paTVpQWkdpNlJVTy9SSjNhZnhKOWlJQ1JJZWN1WVU3aC96My9adWNiU3QxTDRyLzA4aW1pd291dnFvUzNoTCtmd2psUVNtZER4bFZRZFBUMlRMVjBObDN3RzNPcTBoQ3l1MjZBZ1Jmam5IWkhRSFZtZ0p5ckZ3U2RZYVpkVjVHWFUvdmgwYTEzVDV1S2hDTE5ZcHZBTDZMbWc3eU83RENMVXpEM1c1cjdQK0lLSk01OWg5cWRuRXpON1ZTT1hQVlpObFc3ai9XYkhXUjl0M2RRYzVKUk9vWkdLdm1jSWVkRTdqYVgzV1VDSk5WQVBxWjdzYVFDNlZaTC85RG1lM2d0ZVBrQWdteDZLNFFVUktOZ0Y1cEQzUXA4bG1wR2RyUTcwV2prTGNtZWpuYVk0N3FJTTF5anEzaVU9IHJvb3RAYWxmcmVkLVZpcnR1YWxCb3g=' | base64 --decode)"
${kubectl} --namespace="${openbaospace}" exec -i openbao-0 -- bao kv delete secret/keetest/obsync-k8ssecret || true
${kubectl} --namespace="${openbaospace}" exec -i openbao-0 -- bao kv put secret/keetest/obsync-k8ssecret  username="$(echo 'YWxmcmVk' | base64 --decode)" password="$(echo 'VnZGa1pHOHZvN3B6b1NDZkNoN0haVmJvV2xWcm5XSkQ=' | base64 --decode)" url="$(echo 'aHR0cHM6Ly9zbGFpbnRlLmF0' | base64 --decode)" notes="$(echo 'VGVzdCBmb3Igc3RhbmRhcmQgSzhzLXNlY3JldA==' | base64 --decode)"

#!/usr/bin/env bash
set -euo pipefail

openbaospace="openbao"
kubectl="sudo microk8s kubectl"

if [ -z "${OPENBAO_ROOT_TOKEN:-}" ]; then
  echo "Error: OPENBAO_ROOT_TOKEN must be set" >&2
  exit 1
fi

if ! ${kubectl} -n "${openbaospace}" get pod openbao-0 >/dev/null 2>&1; then
  echo "Error: OpenBao pod openbao-0 not found in namespace ${openbaospace}" >&2
  exit 1
fi

# Login
roottoken="${OPENBAO_ROOT_TOKEN}"
echo "${roottoken}" | ${kubectl} --namespace="${openbaospace}" exec -i openbao-0 -- bao login -

echo "Creating policy for secretspace openbao..."
cat <<EOF | ${kubectl} --namespace="${openbaospace}" exec -i openbao-0 -- bao policy write openbao -
# SPDX-License-Identifier: MPL-2.0
# Source and License see: https://github.com/Alfred-Sabitzer/microk8s-ubuntu/tree/main/applications/keepassxc
# Created on 2026-07-06 19:23:26
path "secret/data/openbao/*" {
  capabilities = ["read"]
}
EOF

echo "Configuring role for secretspace openbao..."
${kubectl} --namespace=${openbaospace} exec openbao-0 -- bao write auth/kubernetes/role/openbao-role \
    bound_service_account_names=openbao-sa \
    bound_service_account_namespaces=openbao \
    audience="https://kubernetes.default.svc" \
    policies=openbao \
    ttl=20m

echo "Activating secrets engine and creating secret for secretspace openbao"
${kubectl} --namespace=${openbaospace} exec -i openbao-0 -- bao kv delete -mount=secret openbao || true
echo "Create secret for secretspace openbao"
${kubectl} --namespace="${openbaospace}" exec -i openbao-0 -- bao kv delete secret/openbao/seal || true
${kubectl} --namespace="${openbaospace}" exec -i openbao-0 -- bao kv put secret/openbao/seal  notes="$(echo 'VW5zZWFsIGNvbW1hbmRvCgprdWJlY3RsIGV4ZWMgLWkgb3BlbmJhby0wIC1uIG9wZW5iYW8gLS0gYmFvIG9wZXJhdG9yIHVuc2VhbCAKCi8gJCBiYW8gb3BlcmF0b3IgaW5pdCAtZm9ybWF0IHlhbWwKcmVjb3Zlcnlfa2V5c19iNjQ6Ci0gZWI1cE5DTmgzSEZNLzM2cHJBMFJpdElzOVBCS1JmZUJnOU5DMDR6ZHdsa0sKLSBxeVBoNUp1M3NEWHV3dmg4aVhIdHNLaW16QWNzR3c1Nk9TcGVTL2JFWXh0YwotIExWQ1FqQWozdW5FOEJxRUxNQXQ4b3FCNmpKSlFWeDQ5SW5CSFNmYjNmVGd2Ci0gN2gxTi9uc0JucUJ4SXRZb1BocnIydEZFd01VR0pJYjJscUNVZGRIOUdVSTAKLSBhbmtieWZqdy9FSU12SGk1SjZtTWNrS1BUSDlGUnR1bnU1c0I2Z0o5blNpTApyZWNvdmVyeV9rZXlzX2hleDoKLSA3OWJlNjkzNDIzNjFkYzcxNGNmZjdlYTlhYzBkMTE4YWQyMmNmNGYwNGE0NWY3ODE4M2QzNDJkMzhjZGRjMjU5MGEKLSBhYjIzZTFlNDliYjdiMDM1ZWVjMmY4N2M4OTcxZWRiMGE4YTZjYzA3MmMxYjBlN2EzOTJhNWU0YmY2YzQ2MzFiNWMKLSAyZDUwOTA4YzA4ZjdiYTcxM2MwNmExMGIzMDBiN2NhMmEwN2E4YzkyNTA1NzFlM2QyMjcwNDc0OWY2Zjc3ZDM4MmYKLSBlZTFkNGRmZTdiMDE5ZWEwNzEyMmQ2MjgzZTFhZWJkYWQxNDRjMGM1MDYyNDg2ZjY5NmEwOTQ3NWQxZmQxOTQyMzQKLSA2YTc5MWJjOWY4ZjBmYzQyMGNiYzc4YjkyN2E5OGM3MjQyOGY0YzdmNDU0NmRiYTdiYjliMDFlYTAyN2Q5ZDI4OGIKcmVjb3Zlcnlfa2V5c19zaGFyZXM6IDUKcmVjb3Zlcnlfa2V5c190aHJlc2hvbGQ6IDMKcm9vdF90b2tlbjogcy5ScW1GbGVvcUtaM1ZocWZUbmx5ajJaSUsKdW5zZWFsX2tleXNfYjY0OiBbXQp1bnNlYWxfa2V5c19oZXg6IFtdCnVuc2VhbF9zaGFyZXM6IDEKdW5zZWFsX3RocmVzaG9sZDogMQoKLyAkIGJhbyBzdGF0dXMKS2V5ICAgICAgICAgICAgICAgICAgICAgIFZhbHVlCi0tLSAgICAgICAgICAgICAgICAgICAgICAtLS0tLQpTZWFsIFR5cGUgICAgICAgICAgICAgICAgc3RhdGljClJlY292ZXJ5IFNlYWwgVHlwZSAgICAgICBzaGFtaXIKSW5pdGlhbGl6ZWQgICAgICAgICAgICAgIHRydWUKU2VhbGVkICAgICAgICAgICAgICAgICAgIGZhbHNlClRvdGFsIFJlY292ZXJ5IFNoYXJlcyAgICA1ClRocmVzaG9sZCAgICAgICAgICAgICAgICAzClZlcnNpb24gICAgICAgICAgICAgICAgICAyLjUuMwpCdWlsZCBEYXRlICAgICAgICAgICAgICAgMjAyNi0wNC0yMFQxOToyODoyOVoKU3RvcmFnZSBUeXBlICAgICAgICAgICAgIGZpbGUKQ2x1c3RlciBOYW1lICAgICAgICAgICAgIHRlc3Qtb3BlbmJhby1jbHVzdGVyCkNsdXN0ZXIgSUQgICAgICAgICAgICAgICAxMTQ2OWUzZC1jYzI1LTU3YWEtYWExNi1mYzQzYzU2M2FlOWQKSEEgRW5hYmxlZCAgICAgICAgICAgICAgIGZhbHNlCi8gJCAKCg==' | base64 --decode)"

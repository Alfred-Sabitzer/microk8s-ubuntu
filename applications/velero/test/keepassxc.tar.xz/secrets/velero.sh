#!/usr/bin/env bash
set -euo pipefail

openbaospace="openbao"
kubectl="sudo microk8s kubectl"

if [ -z "${OPENBAO_ROOT_TOKEN:-}" ]; then
  echo "Error: OPENBAO_ROOT_TOKEN must be set" >&2
  exit 1
fi

if ! ${kubectl} -n "${openbaospace}" get pod openbao-0 >/dev/null 2>&1; then
  echo "Error: OpenBao pod openbao-0 not found in namespace ${openbaospace}" >&2
  exit 1
fi

# Login
roottoken="${OPENBAO_ROOT_TOKEN}"
echo "${roottoken}" | ${kubectl} --namespace="${openbaospace}" exec -i openbao-0 -- bao login -

echo "Creating policy for secretspace velero..."
cat <<EOF | ${kubectl} --namespace="${openbaospace}" exec -i openbao-0 -- bao policy write velero -
# SPDX-License-Identifier: MPL-2.0
# Source and License see: https://github.com/Alfred-Sabitzer/microk8s-ubuntu/tree/main/applications/keepassxc
# Created on 2026-07-06 19:23:26
path "secret/data/velero/*" {
  capabilities = ["read"]
}
EOF

echo "Configuring role for secretspace velero..."
${kubectl} --namespace=${openbaospace} exec openbao-0 -- bao write auth/kubernetes/role/velero-role \
    bound_service_account_names=velero-sa \
    bound_service_account_namespaces=velero \
    audience="https://kubernetes.default.svc" \
    policies=velero \
    ttl=20m

echo "Activating secrets engine and creating secret for secretspace velero"
${kubectl} --namespace=${openbaospace} exec -i openbao-0 -- bao kv delete -mount=secret velero || true
echo "Create secret for secretspace velero"
${kubectl} --namespace="${openbaospace}" exec -i openbao-0 -- bao kv delete secret/velero/velero || true
${kubectl} --namespace="${openbaospace}" exec -i openbao-0 -- bao kv put secret/velero/velero  cloud="$(echo 'W2RlZmF1bHRdCmF3c19hY2Nlc3Nfa2V5X2lkPTVmNDgwZjA5NThjYTU1N2E0YmE1CmF3c19zZWNyZXRfYWNjZXNzX2tleT1Pc3FpVEtZK2RKOXhqRVFSaW5QRVU5UVkrVzhaejVPZndCUlNydXJPb1RRPQ==' | base64 --decode)"
${kubectl} --namespace="${openbaospace}" exec -i openbao-0 -- bao kv delete secret/velero/velero-bucket-meta || true
${kubectl} --namespace="${openbaospace}" exec -i openbao-0 -- bao kv put secret/velero/velero-bucket-meta  notes="$(echo 'PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0KW0lORk9dIEJ1Y2tldCBEZXRhaWxzOgo9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PQpCdWNrZXQgTmFtZTogdGVzdC12ZWxlcm8KewogICAgImJ1Y2tldCI6ICJ0ZXN0LXZlbGVybyIsCiAgICAidGVuYW50IjogIiIsCiAgICAidmVyc2lvbmluZyI6ICJvZmYiLAogICAgInpvbmVncm91cCI6ICJmMTQ5NTFmMS1iNjAwLTQ5Y2QtODZhYS0wNDE0NjUxOWEzNjUiLAogICAgInBsYWNlbWVudF9ydWxlIjogImRlZmF1bHQtcGxhY2VtZW50IiwKICAgICJleHBsaWNpdF9wbGFjZW1lbnQiOiB7CiAgICAgICAgImRhdGFfcG9vbCI6ICIiLAogICAgICAgICJkYXRhX2V4dHJhX3Bvb2wiOiAiIiwKICAgICAgICAiaW5kZXhfcG9vbCI6ICIiCiAgICB9LAogICAgImlkIjogIjc0YzQzYWQ1LWViODktNGEzNC04M2I1LWY4ZWI5Y2QxMzIyNS44MjE0MzMzLjIiLAogICAgIm1hcmtlciI6ICI3NGM0M2FkNS1lYjg5LTRhMzQtODNiNS1mOGViOWNkMTMyMjUuODIxNDMzMy4yIiwKICAgICJpbmRleF90eXBlIjogIk5vcm1hbCIsCiAgICAiaW5kZXhfZ2VuZXJhdGlvbiI6IDAsCiAgICAibnVtX3NoYXJkcyI6IDExLAogICAgIm9iamVjdF9sb2NrX2VuYWJsZWQiOiBmYWxzZSwKICAgICJtZmFfZW5hYmxlZCI6IGZhbHNlLAogICAgIm93bmVyIjogInRlc3QtdmVsZXJvIiwKICAgICJ2ZXIiOiAiMCMxLDEjMSwyIzEsMyMxLDQjMSw1IzEsNiMxLDcjMSw4IzEsOSMxLDEwIzEiLA==' | base64 --decode)"

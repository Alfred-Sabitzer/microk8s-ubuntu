/*
Copyright 2025 The Kubernetes Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package reconciler

import (
	"context"
	"errors"
	"fmt"
	"regexp"
	"slices"
	"time"

	"github.com/go-logr/logr"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
	kerrors "k8s.io/apimachinery/pkg/api/errors"
	"k8s.io/apimachinery/pkg/runtime"
	"k8s.io/apimachinery/pkg/types"
	"k8s.io/utils/ptr"
	ctrl "sigs.k8s.io/controller-runtime"
	"sigs.k8s.io/controller-runtime/pkg/client"
	ctrlutil "sigs.k8s.io/controller-runtime/pkg/controller/controllerutil"
	ctrlpredicate "sigs.k8s.io/controller-runtime/pkg/predicate"
	"sigs.k8s.io/controller-runtime/pkg/reconcile"

	cosiapi "sigs.k8s.io/container-object-storage-interface/client/apis/objectstorage/v1alpha2"
	cosierr "sigs.k8s.io/container-object-storage-interface/internal/errors"
	cosipredicate "sigs.k8s.io/container-object-storage-interface/internal/predicate"
	"sigs.k8s.io/container-object-storage-interface/internal/protocol"
	cosiproto "sigs.k8s.io/container-object-storage-interface/proto"
	"sigs.k8s.io/container-object-storage-interface/sidecar/internal/translator"
)

// These duplicate the +kubebuilder:validation:MaxLength and :Pattern markers on
// BucketStatus.BucketID in client/apis/objectstorage/v1alpha2/bucket_types.go; markers must be
// literals, so keep the two in sync by hand.
const (
	bucketIDPatternStr = `^[a-zA-Z0-9/._-]+$`
	bucketIDMaxLength  = 2048
)

var bucketIDPattern = regexp.MustCompile(bucketIDPatternStr)

// validateBucketID checks a bucket ID against the length and character constraints shared by the
// bucket_id fields of the DriverGenerateBucketId and DriverCreateBucket RPCs (see proto/spec.md).
// Checking here reports a non-conforming driver ID as a driver bug, rather than letting it surface
// later as an API server rejection of the status write.
func validateBucketID(id string) error {
	allErrs := []string{}

	if len(id) > bucketIDMaxLength {
		allErrs = append(allErrs, fmt.Sprintf("must be no more than %d characters: length=%d", bucketIDMaxLength, len(id)))
	}

	if !bucketIDPattern.MatchString(id) {
		allErrs = append(allErrs, fmt.Sprintf("must match pattern %q", bucketIDPatternStr))
	}

	if len(allErrs) > 0 {
		return fmt.Errorf("bucket ID %q is invalid: %v", id, allErrs)
	}
	return nil
}

// BucketReconciler reconciles a Bucket object
type BucketReconciler struct {
	client.Client
	Scheme     *runtime.Scheme
	DriverInfo DriverInfo
}

// +kubebuilder:rbac:groups=objectstorage.k8s.io,resources=buckets,verbs=get;list;watch;update;patch
// +kubebuilder:rbac:groups=objectstorage.k8s.io,resources=buckets/status,verbs=get;update;patch
// +kubebuilder:rbac:groups=objectstorage.k8s.io,resources=buckets/finalizers,verbs=update

// Reconcile is part of the main kubernetes reconciliation loop which aims to
// move the current state of the cluster closer to the desired state.
func (r *BucketReconciler) Reconcile(ctx context.Context, req ctrl.Request) (ctrl.Result, error) {
	logger := ctrl.LoggerFrom(ctx, "driverName", r.DriverInfo.Name)

	bucket := &cosiapi.Bucket{}
	if err := r.Get(ctx, req.NamespacedName, bucket); err != nil {
		if kerrors.IsNotFound(err) {
			logger.V(1).Info("not reconciling nonexistent Bucket")
			return ctrl.Result{}, nil
		}
		// no resource to add status to or report an event for
		logger.Error(err, "failed to get Bucket")
		return ctrl.Result{}, err
	}

	err := r.reconcile(ctx, logger, bucket)
	if err != nil {
		// Record any error as a timestamped error in the status.
		if bucket.Status.ReadyToUse == nil {
			bucket.Status.ReadyToUse = ptr.To(false)
		}
		bucket.Status.Error = cosiapi.NewTimestampedError(time.Now(), err.Error())
		if updErr := r.Status().Update(ctx, bucket); updErr != nil {
			logger.Error(err, "failed to update Bucket status after reconcile error", "updateError", updErr)
			// If status update fails, we must retry the error regardless of the reconcile return.
			// The reconcile needs to run again to make sure the status is eventually updated.
			return reconcile.Result{}, err
		}

		if errors.Is(err, cosierr.NonRetryableError(nil)) {
			return reconcile.Result{}, reconcile.TerminalError(err)
		}
		return reconcile.Result{}, err
	}

	// On success, clear any errors in the status.
	if bucket.Status.Error != nil && bucket.DeletionTimestamp.IsZero() {
		if bucket.Status.ReadyToUse == nil {
			bucket.Status.ReadyToUse = ptr.To(false)
		}
		bucket.Status.Error = nil
		if err := r.Status().Update(ctx, bucket); err != nil {
			logger.Error(err, "failed to update BucketClaim status after reconcile success")
			// Retry the reconcile so status can be updated eventually.
			return reconcile.Result{}, err
		}
	}

	return reconcile.Result{}, err
}

// SetupWithManager sets up the controller with the Manager.
func (r *BucketReconciler) SetupWithManager(mgr ctrl.Manager) error {
	return ctrl.NewControllerManagedBy(mgr).
		For(&cosiapi.Bucket{}).
		WithEventFilter(
			ctrlpredicate.And(
				driverNameMatchesPredicate(r.DriverInfo.Name), // only opt in to reconciles with matching driver name
				ctrlpredicate.Or(
					// this is the primary bucket controller and should reconcile ALL Create/Delete/Generic events
					cosipredicate.AnyCreate(),
					cosipredicate.AnyDelete(),
					cosipredicate.AnyGeneric(),
					// opt in to desired Update events
					cosipredicate.GenerationChangedInUpdateOnly(), // reconcile spec changes
					cosipredicate.DeletionTimestampAdded(),
					cosipredicate.BucketClaimBeingDeletedAnnotationAdded(), // annotation gates deletion, so must reconcile when added
					cosipredicate.ProtectionFinalizerRemoved(r.Scheme),     // re-add protection finalizer if removed
				),
			),
		).
		Named("bucket").
		Complete(r)
}

func (r *BucketReconciler) reconcile(ctx context.Context, logger logr.Logger, bucket *cosiapi.Bucket) error {
	if bucket.Spec.DriverName != r.DriverInfo.Name {
		// keep this log to help debug any issues that might arise with predicate logic
		logger.Info("not reconciling bucket with non-matching driver name %q", bucket.Spec.DriverName)
		return nil
	}

	if !bucket.GetDeletionTimestamp().IsZero() {
		logger.Info("beginning Bucket deletion")
		return r.reconcileDelete(ctx, logger, bucket)
	}

	// BucketClaim is deleting, but Bucket not marked for deletion
	if _, claimDeleting := bucket.Annotations[cosiapi.BucketClaimBeingDeletedAnnotation]; claimDeleting {
		logger.Info("not reconciling Bucket whose BucketClaim is being deleted")
		bucket.Status.ReadyToUse = ptr.To(false)
		bucket.Status.Error = nil // previous error is no longer relevant
		if err := r.Status().Update(ctx, bucket); err != nil {
			logger.Error(err, "failed to update Bucket status before deletion")
			return fmt.Errorf("failed to update Bucket status before deletion: %w", err)
		}
		return nil
	}

	requiredProtos, err := objectProtocolListFromApiList(bucket.Spec.Protocols)
	if err != nil {
		logger.Error(err, "failed to parse protocol list")
		return cosierr.NonRetryableError(err)
	}

	if err := validateDriverSupportsProtocols(r.DriverInfo, requiredProtos); err != nil {
		logger.Error(err, "protocol(s) are unsupported")
		return cosierr.NonRetryableError(err)
	}

	isStaticProvisioning := bucket.Spec.ExistingBucketID != ""
	if isStaticProvisioning {
		logger = logger.WithValues("provisioningStrategy", "static")
	} else {
		logger = logger.WithValues("provisioningStrategy", "dynamic")
	}

	logger.V(1).Info("reconciling Bucket")

	didAdd := ctrlutil.AddFinalizer(bucket, cosiapi.ProtectionFinalizer)
	if didAdd {
		if err := r.Update(ctx, bucket); err != nil {
			logger.Error(err, "failed to add protection finalizer")
			return fmt.Errorf("failed to add protection finalizer: %w", err)
		}
	}

	// status.bucketID is always persisted before the backend bucket is provisioned, for both
	// provisioning strategies, so every backend bucket that might exist is reachable by an ID
	// Kubernetes already holds. Dynamic provisioning mints the ID with DriverGenerateBucketId;
	// static provisioning takes it from spec.existingBucketID.
	bucketID, err := getBucketIdIfSet(bucket)
	if err != nil {
		logger.Error(err, "failed to determine the bucket ID")
		return err
	}

	if bucketID == "" {
		bucketID, err = r.generateBucketID(ctx, logger, generateIdParams{
			name:           bucket.Name,
			requiredProtos: requiredProtos,
			parameters:     bucket.Spec.Parameters,
		})
		if err != nil {
			return err
		}
	}

	logger = logger.WithValues("bucketID", bucketID)

	if bucketID == "" {
		// Having a bucketId is a hard requirement for provisioning.
		logger.Error(nil, "internal error: no bucket ID determined before provisioning")
		return cosierr.NonRetryableError(
			fmt.Errorf("internal error: no bucket ID determined before provisioning"))
	}

	if bucket.Status.BucketID == "" {
		if err := r.recordBucketId(ctx, logger, bucket, bucketID); err != nil {
			return err
		}
	}

	var provisionedBucket *provisionedBucketDetails
	if isStaticProvisioning {
		provisionedBucket, err = r.staticProvision(ctx, logger, staticProvisionParams{
			existingBucketID: bucketID,
			requiredProtos:   requiredProtos,
			parameters:       bucket.Spec.Parameters,
			claimRef:         bucket.Spec.BucketClaimRef,
		})
	} else {
		provisionedBucket, err = r.dynamicProvision(ctx, logger, dynamicProvisionParams{
			bucketID:       bucketID,
			requiredProtos: requiredProtos,
			parameters:     bucket.Spec.Parameters,
			claimRef:       bucket.Spec.BucketClaimRef,
		})
	}
	if err != nil {
		return err
	}

	// final validation and status updates are the same for dynamic and static provisioning

	if len(provisionedBucket.supportedProtos) == 0 {
		logger.Error(nil, "created bucket supports no protocols")
		return cosierr.NonRetryableError(fmt.Errorf("created bucket supports no protocols"))
	}

	if err := validateBucketSupportsProtocols(provisionedBucket.supportedProtos, bucket.Spec.Protocols); err != nil {
		logger.Error(err, "bucket required protocols missing")
		return cosierr.NonRetryableError(fmt.Errorf("bucket required protocols missing: %w", err))
	}

	bucket.Status = cosiapi.BucketStatus{
		ReadyToUse: ptr.To(true),
		// already persisted before provisioning; carried forward because status is replaced whole
		BucketID:   bucketID,
		Protocols:  provisionedBucket.supportedProtos,
		BucketInfo: provisionedBucket.allProtoBucketInfo,
		Error:      nil,
	}
	if err := r.Status().Update(ctx, bucket); err != nil {
		logger.Error(err, "failed to update Bucket status after successful bucket creation")
		return fmt.Errorf("failed to update Bucket status after successful bucket creation: %w", err)
	}

	return nil
}

func (r *BucketReconciler) reconcileDelete(
	ctx context.Context, logger logr.Logger, bucket *cosiapi.Bucket,
) error {
	logger = logger.WithValues("deletionPolicy", bucket.Spec.DeletionPolicy)
	if bucket.Spec.DeletionPolicy != cosiapi.BucketDeletionPolicyDelete {
		logger.Error(nil, "will not delete Bucket with non-delete deletion policy")
		return cosierr.NonRetryableError(
			fmt.Errorf("will not delete Bucket with non-delete deletion policy %q", bucket.Spec.DeletionPolicy))
	}

	_, claimDeleting := bucket.Annotations[cosiapi.BucketClaimBeingDeletedAnnotation]
	claimRef := bucket.Spec.BucketClaimRef
	logger = logger.WithValues("bucketClaimBeingDeleted", claimDeleting, "bucketClaimRef", claimRef)
	if !claimDeleting {
		// Annotation means deletion should proceed. Not present, needs more checking.
		if claimRef.UID != types.UID("") {
			// Bucket is bound to a BucketClaim, so cannot delete
			// BucketClaim controller will apply the annotation when it cleans up the claim
			logger.Error(nil, "will not delete Bucket bound to a non-deleting BucketClaim")
			return cosierr.NonRetryableError(
				fmt.Errorf("will not delete Bucket bound to a non-deleting BucketClaim: %#v", claimRef))
		}
		// claimRef.UID == "": not bound to a BucketClaim, so can delete
	}

	logger.Info("proceeding with Bucket deletion")

	bucket.Status.ReadyToUse = ptr.To(false)
	bucket.Status.Error = nil // previous error is no longer relevant
	if err := r.Status().Update(ctx, bucket); err != nil {
		logger.Error(err, "failed to update Bucket status before deletion")
		return fmt.Errorf("failed to update Bucket status before deletion: %w", err)
	}

	if bucket.Status.BucketID != "" {
		logger.Info("calling driver to delete bucket", "bucketID", bucket.Status.BucketID)
		_, err := r.DriverInfo.ProvisionerClient.DriverDeleteBucket(ctx,
			&cosiproto.DriverDeleteBucketRequest{
				BucketId:   bucket.Status.BucketID,
				Parameters: bucket.Spec.Parameters,
			},
		)
		if err != nil {
			logger.Error(err, "DriverDeleteBucket error")
			if rpcErrorIsRetryable(status.Code(err)) {
				return err
			}
			// Do not proceed with k8s resource cleanup after a non-retryable error. Proceeding would
			// risk leaving backend resources orphaned without any clear indication to administrators
			// that they need to do manual cleanup if desired. If this is a sidecar or driver error, an
			// update could resolve the issue to allow a future deletion to succeed.
			return cosierr.NonRetryableError(err)
		}
	} else {
		logger.Info("not calling driver to delete bucket with no recorded bucketID")
	}

	ctrlutil.RemoveFinalizer(bucket, cosiapi.ProtectionFinalizer)
	if err := r.Update(ctx, bucket); err != nil {
		logger.Error(err, "failed to remove finalizer")
		return fmt.Errorf("failed to remove finalizer: %w", err)
	}

	return nil
}

// getBucketIdIfSet returns the bucket ID that Kubernetes already holds for this Bucket, or an
// empty string when it holds none and the driver must generate one. `status.bucketID` takes precedence
// over `spec.existingBucketID`.
func getBucketIdIfSet(bucket *cosiapi.Bucket) (string, error) {
	if bucket.Status.BucketID == "" && ptr.Deref(bucket.Status.ReadyToUse, false) {
		// A Bucket that has not been assigned an ID cannot have been provisioned, so this sidecar
		// never writes this combination. Since COSI cannot tell how this situation came about,
		// return a NonRetryableError.
		return "", cosierr.NonRetryableError(
			fmt.Errorf("invalid Bucket status: readyToUse is true but no bucket ID is assigned"))
	}

	if bucket.Status.BucketID != "" {
		return bucket.Status.BucketID, nil
	}

	return bucket.Spec.ExistingBucketID, nil
}

// recordBucketId persists the bucket ID to status.bucketID. This runs before any backend bucket
// exists, so readyToUse is hard coded to false.
func (r *BucketReconciler) recordBucketId(
	ctx context.Context, logger logr.Logger, bucket *cosiapi.Bucket, bucketID string,
) error {
	bucket.Status.BucketID = bucketID
	bucket.Status.ReadyToUse = ptr.To(false)

	if err := r.Status().Update(ctx, bucket); err != nil {
		logger.Error(err, "failed to update Bucket status with the bucket ID")
		return fmt.Errorf("failed to update Bucket status with the bucket ID: %w", err)
	}
	logger.Info("recorded bucket ID")

	return nil
}

// Details about provisioned bucket for both dynamic and static provisioning.
// A struct with named params allows for future expansion easily.
// When param lists get long, named fields help with readability, review, and maintenance.
type provisionedBucketDetails struct {
	supportedProtos    []cosiapi.ObjectProtocol
	allProtoBucketInfo map[string]string
}

// Parameters for the DriverGenerateBucketId step of the dynamic provisioning workflow.
// A struct with named params allows for future expansion easily.
// When param lists get long, named fields help with readability, review, and maintenance.
type generateIdParams struct {
	name           string
	requiredProtos []*cosiproto.ObjectProtocol
	parameters     map[string]string
}

// Call DriverGenerateBucketId and return the generated bucket ID. The driver generates the ID
// without provisioning any backend resource. The caller is responsible for persisting the
// returned ID to status.bucketID before provisioning the backend bucket (dynamicProvision): this
// guarantees that any backend bucket created there is reachable by an ID that is already recorded
// in Kubernetes, even if the sidecar crashes between the two calls.
func (r *BucketReconciler) generateBucketID(
	ctx context.Context,
	logger logr.Logger,
	generate generateIdParams,
) (string, error) {
	// The input parameters given here are the same parameters later used to provision the bucket,
	// so a driver may use any of them when determining bucket_id. See proto/spec.md.
	resp, err := r.DriverInfo.ProvisionerClient.DriverGenerateBucketId(ctx,
		&cosiproto.DriverGenerateBucketIdRequest{
			Name:       generate.name,
			Protocols:  generate.requiredProtos,
			Parameters: generate.parameters,
		},
	)
	if err != nil {
		logger.Error(err, "DriverGenerateBucketIdRequest error")
		if rpcErrorIsRetryable(status.Code(err)) {
			return "", err
		}
		return "", cosierr.NonRetryableError(err)
	}

	if resp.BucketId == "" {
		logger.Error(nil, "generated bucket ID missing")
		// driver behavior is unlikely to change if the request is retried
		return "", cosierr.NonRetryableError(fmt.Errorf("generated bucket ID missing"))
	}

	if err := validateBucketID(resp.BucketId); err != nil {
		// A driver that returns a non-conforming ID will keep returning it, and the ID would
		// otherwise surface later as an API server rejection of the status write.
		logger.Error(err, "generated bucket ID is invalid", "bucketID", resp.BucketId)
		return "", cosierr.NonRetryableError(err)
	}

	return resp.BucketId, nil
}

// Parameters for dynamic provisioning workflow.
// A struct with named params allows for future expansion easily.
// When param lists get long, named fields help with readability, review, and maintenance.
type dynamicProvisionParams struct {
	bucketID       string
	requiredProtos []*cosiproto.ObjectProtocol
	parameters     map[string]string
	claimRef       cosiapi.BucketClaimReference
}

// Run dynamic provisioning workflow.
func (r *BucketReconciler) dynamicProvision(
	ctx context.Context,
	logger logr.Logger,
	dynamic dynamicProvisionParams,
) (
	details *provisionedBucketDetails,
	err error,
) {
	cr := dynamic.claimRef
	if cr.Name == "" || cr.Namespace == "" || cr.UID == "" {
		// likely a malformed bucket intended for static provisioning (possible COSI controller bug)
		logger.Error(nil, "all bucketClaimRef fields must be set for dynamic provisioning", "bucketClaimRef", cr)
		return nil, cosierr.NonRetryableError(
			fmt.Errorf("all bucketClaimRef fields must be set for dynamic provisioning: %#v", cr))
	}

	resp, err := r.DriverInfo.ProvisionerClient.DriverCreateBucket(ctx,
		&cosiproto.DriverCreateBucketRequest{
			BucketId:   dynamic.bucketID,
			Protocols:  dynamic.requiredProtos,
			Parameters: dynamic.parameters,
		},
	)
	if err != nil {
		logger.Error(err, "DriverCreateBucketRequest error")
		if rpcErrorIsRetryable(status.Code(err)) {
			return nil, err
		}
		return nil, cosierr.NonRetryableError(err)
	}

	protoResp := resp.Protocols
	if protoResp == nil {
		logger.Error(nil, "created bucket protocol response missing")
		return nil, cosierr.NonRetryableError(fmt.Errorf("created bucket protocol response missing"))
	}

	var noValidation *translator.ValidationConfig = nil
	supportedProtos, allBucketInfo, err := translator.BucketInfoToApi(protoResp, noValidation)
	if err != nil {
		logger.Error(nil, "errors translating bucket info")
		return nil, cosierr.NonRetryableError(err)
	}

	details = &provisionedBucketDetails{
		supportedProtos:    supportedProtos,
		allProtoBucketInfo: allBucketInfo,
	}
	return details, nil
}

// Parameters for static provisioning workflow.
type staticProvisionParams struct {
	existingBucketID string
	requiredProtos   []*cosiproto.ObjectProtocol
	parameters       map[string]string
	claimRef         cosiapi.BucketClaimReference
}

// Run static provisioning workflow.
func (r *BucketReconciler) staticProvision(
	ctx context.Context,
	logger logr.Logger,
	static staticProvisionParams,
) (*provisionedBucketDetails, error) {
	ref := static.claimRef
	if ref.Name == "" || ref.Namespace == "" {
		logger.Error(nil, "bucketClaimRef namespace and name must be set for static provisioning", "bucketClaimRef", ref)
		return nil, cosierr.NonRetryableError(
			fmt.Errorf("bucketClaimRef namespace and name must be set for static provisioning: %#v", ref))
	}

	resp, err := r.DriverInfo.ProvisionerClient.DriverGetBucket(ctx,
		&cosiproto.DriverGetBucketRequest{
			BucketId:   static.existingBucketID,
			Protocols:  static.requiredProtos,
			Parameters: static.parameters,
		},
	)
	if err != nil {
		if status.Code(err) == codes.NotFound {
			err = fmt.Errorf("waiting for backend bucket to exist: %w", err)
			logger.Error(err, "DriverGetBucket error")
			return nil, err
		}

		logger.Error(err, "DriverGetBucket error")
		if rpcErrorIsRetryable(status.Code(err)) {
			return nil, err
		}
		return nil, cosierr.NonRetryableError(err)
	}

	protoResp := resp.Protocols
	if protoResp == nil {
		logger.Error(nil, "existing bucket protocol response missing")
		return nil, cosierr.NonRetryableError(fmt.Errorf("existing bucket protocol response missing"))
	}

	var noValidation *translator.ValidationConfig = nil
	supportedProtos, allBucketInfo, err := translator.BucketInfoToApi(protoResp, noValidation)
	if err != nil {
		logger.Error(err, "errors translating existing bucket info")
		return nil, cosierr.NonRetryableError(err)
	}

	return &provisionedBucketDetails{
		supportedProtos:    supportedProtos,
		allProtoBucketInfo: allBucketInfo,
	}, nil
}

// convert an API proto list into an RPC proto message list
func objectProtocolListFromApiList(apiList []cosiapi.ObjectProtocol) ([]*cosiproto.ObjectProtocol, error) {
	errs := []error{}
	out := []*cosiproto.ObjectProtocol{}

	for _, apiProto := range apiList {
		rpcProto, err := protocol.ObjectProtocolTranslator{}.ApiToRpc(apiProto)
		if err != nil {
			errs = append(errs, err)
			continue
		}
		out = append(out, &cosiproto.ObjectProtocol{
			Type: rpcProto,
		})
	}

	if len(errs) > 0 {
		return nil, fmt.Errorf("failed to parse protocol list: %w", errors.Join(errs...))
	}
	return out, nil
}

// validate that the required protocols (if given) are supported by the driver
func validateDriverSupportsProtocols(driver DriverInfo, required []*cosiproto.ObjectProtocol) error {
	unsupportedProtos := []string{}

	for _, proto := range required {
		if !driver.SupportsProtocol(proto.Type) {
			unsupportedProtos = append(unsupportedProtos, proto.Type.String())
		}
	}

	if len(unsupportedProtos) > 0 {
		return fmt.Errorf("driver %q does not support protocols: %v", driver.Name, unsupportedProtos)
	}
	return nil
}

// validate the required protocols (if given) are in the supported list (from bucket provisioning results)
func validateBucketSupportsProtocols(supported, required []cosiapi.ObjectProtocol) error {
	unsupported := []string{}
	for _, req := range required {
		if !slices.Contains(supported, req) {
			unsupported = append(unsupported, string(req))
		}
	}
	if len(unsupported) > 0 {
		return fmt.Errorf("required protocols are not supported: %v", unsupported)
	}
	return nil
}

/*
Copyright 2026 The Kubernetes Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package reconciler_test

import (
	"context"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/types"
	"k8s.io/utils/ptr"
	ctrl "sigs.k8s.io/controller-runtime"
	"sigs.k8s.io/controller-runtime/pkg/client"
	"sigs.k8s.io/controller-runtime/pkg/reconcile"

	cosiapi "sigs.k8s.io/container-object-storage-interface/client/apis/objectstorage/v1alpha2"
	controller "sigs.k8s.io/container-object-storage-interface/controller/pkg/reconciler"
	cositest "sigs.k8s.io/container-object-storage-interface/internal/test"
	sidecartest "sigs.k8s.io/container-object-storage-interface/internal/test/sidecar"
	cosiproto "sigs.k8s.io/container-object-storage-interface/proto"
)

var (
	// use the opinionated S3 class's driver name so we can use test utils to simulate sidecar
	// behavior tests that depend on Bucket reconciliation
	s3DriverName = cositest.OpinionatedS3BucketClass().Spec.DriverName

	// valid claim used by dynamic provisioning tests
	baseDynamicClaim = cosiapi.BucketClaim{
		ObjectMeta: metav1.ObjectMeta{
			Name:      "my-bucket",
			Namespace: "my-ns",
			UID:       "dynamicuid",
		},
		Spec: cosiapi.BucketClaimSpec{
			BucketClassName: "s3-class",
			Protocols: []cosiapi.ObjectProtocol{
				cosiapi.ObjectProtocolS3,
			},
		},
	}

	// valid class compatible with dynamic claim above
	baseBucketClass = cosiapi.BucketClass{
		ObjectMeta: metav1.ObjectMeta{
			Name: "s3-class",
		},
		Spec: cosiapi.BucketClassSpec{
			DriverName:     s3DriverName,
			DeletionPolicy: cosiapi.BucketDeletionPolicyDelete,
			Parameters: map[string]string{
				"maxSize": "100Gi",
				"maxIops": "10",
			},
		},
	}

	// valid claim used by static provisioning tests
	baseStaticClaim = cosiapi.BucketClaim{
		ObjectMeta: metav1.ObjectMeta{
			Name:      "my-bucket", // same name as dynamic so Get() can be reused between tests
			Namespace: "my-ns",
			UID:       "staticuid",
		},
		Spec: cosiapi.BucketClaimSpec{
			ExistingBucketName: "static-bucket",
			Protocols: []cosiapi.ObjectProtocol{
				cosiapi.ObjectProtocolS3,
			},
		},
	}

	// valid static bucket compatible with static claim above
	baseStaticBucket = cosiapi.Bucket{
		ObjectMeta: metav1.ObjectMeta{
			Name: "static-bucket",
		},
		Spec: cosiapi.BucketSpec{
			DriverName:     cositest.OpinionatedS3BucketClass().Spec.DriverName,
			DeletionPolicy: cosiapi.BucketDeletionPolicyRetain,
			BucketClaimRef: cosiapi.BucketClaimReference{
				Name:      "my-bucket",
				Namespace: "my-ns",
				UID:       "staticuid",
			},
		},
	}
)

// Get claim and both dynamic and static buckets.
func getAllClaimResources(
	bootstrapped *cositest.Dependencies,
) (
	claim *cosiapi.BucketClaim,
	dynamicBucket *cosiapi.Bucket,
	staticBucket *cosiapi.Bucket,
) {
	ctx := bootstrapped.ContextWithLogger
	client := bootstrapped.Client
	var err error

	claim = &cosiapi.BucketClaim{}
	err = client.Get(ctx, cositest.NsName(&baseDynamicClaim), claim)
	if err != nil {
		claim = nil
	}
	dynamicBucket = &cosiapi.Bucket{}
	err = client.Get(ctx, types.NamespacedName{Name: "bc-dynamicuid"}, dynamicBucket)
	if err != nil {
		dynamicBucket = nil
	}
	staticBucket = &cosiapi.Bucket{}
	err = client.Get(ctx, cositest.NsName(&baseStaticBucket), staticBucket)
	if err != nil {
		staticBucket = nil
	}

	return claim, dynamicBucket, staticBucket
}

// Get claim and its associated bucket. Requires the claim to have been reconciled at least once.
func getClaimAndBucket(
	bootstrapped *cositest.Dependencies,
) (
	claim *cosiapi.BucketClaim,
	bucket *cosiapi.Bucket,
) {
	ctx := bootstrapped.ContextWithLogger
	client := bootstrapped.Client
	var err error

	claim = &cosiapi.BucketClaim{}
	err = client.Get(ctx, cositest.NsName(&baseDynamicClaim), claim)
	if err != nil {
		claim = nil
	}

	bucket = &cosiapi.Bucket{}
	err = client.Get(ctx, cositest.BucketNsName(claim), bucket)
	if err != nil {
		bucket = nil
	}

	return claim, bucket
}

func claimReconcilerForClient(client client.Client) *controller.BucketClaimReconciler {
	return &controller.BucketClaimReconciler{
		Client: client,
		Scheme: client.Scheme(),
	}
}

// Test dynamic provisioning, successful initialization, using base class and claim
func dynamicInitializationTest(t *testing.T) (
	bootstrappedDeps *cositest.Dependencies,
) {
	bootstrapped := cositest.MustBootstrap(t,
		baseDynamicClaim.DeepCopy(),
		baseBucketClass.DeepCopy(),
	)
	r := claimReconcilerForClient(bootstrapped.Client)
	ctx := bootstrapped.ContextWithLogger

	res, err := r.Reconcile(ctx, ctrl.Request{NamespacedName: cositest.NsName(&baseDynamicClaim)})
	assert.NoError(t, err)
	assert.Empty(t, res)

	claim, bucket, _ := getAllClaimResources(bootstrapped)

	assert.Contains(t, claim.GetFinalizers(), cosiapi.ProtectionFinalizer)
	status := claim.Status
	assert.Equal(t, "bc-dynamicuid", status.BoundBucketName)
	assert.Equal(t, false, *status.ReadyToUse)
	assert.Empty(t, status.Protocols)
	assert.Nil(t, status.Error)

	// intermediate bucket generation is already thoroughly tested elsewhere
	// just test a couple basic fields to ensure it's integrated
	assert.NotContains(t, bucket.GetFinalizers(), cosiapi.ProtectionFinalizer)
	assert.Equal(t, baseBucketClass.Spec.DriverName, bucket.Spec.DriverName)
	assert.Equal(t, baseDynamicClaim.Spec.Protocols, bucket.Spec.Protocols)
	assert.Empty(t, bucket.Status)

	return bootstrapped
}

// Test static provisioning, successful initialization, using base static claim and bucket
func staticInitializationTest(
	t *testing.T,
	presetBcUid bool, // whether to "preset" the BucketClaimRef UID to that of the claim
) (
	bootstrappedDeps *cositest.Dependencies,
) {
	initBucket := baseStaticBucket.DeepCopy()
	if presetBcUid {
		initBucket.Spec.BucketClaimRef.UID = baseStaticClaim.UID
	} else {
		initBucket.Spec.BucketClaimRef.UID = ""
	}
	bootstrapped := cositest.MustBootstrap(t,
		baseStaticClaim.DeepCopy(),
		initBucket,
	)
	r := claimReconcilerForClient(bootstrapped.Client)
	ctx := bootstrapped.ContextWithLogger

	res, err := r.Reconcile(ctx, ctrl.Request{NamespacedName: cositest.NsName(&baseStaticClaim)})
	assert.NoError(t, err)
	assert.Empty(t, res)

	claim, dynamicBucket, staticBucket := getAllClaimResources(bootstrapped)

	assert.Contains(t, claim.GetFinalizers(), cosiapi.ProtectionFinalizer)
	assert.Equal(t, "static-bucket", claim.Status.BoundBucketName)
	assert.Equal(t, false, *claim.Status.ReadyToUse)
	assert.Empty(t, claim.Status.Protocols)
	assert.Nil(t, claim.Status.Error)

	// Bucket claim ref UID must match claim UID
	// set either by controller or by admin
	assert.Equal(t, "staticuid", string(staticBucket.Spec.BucketClaimRef.UID))

	{ // bucket should be otherwise unchanged since it's statically provisioned
		initWithRefUid := initBucket.DeepCopy()
		initWithRefUid.Spec.BucketClaimRef.UID = "staticuid"
		assert.Equal(t, initWithRefUid.Finalizers, staticBucket.Finalizers)
		assert.Equal(t, initWithRefUid.Spec, staticBucket.Spec)
		assert.Equal(t, initWithRefUid.Status, staticBucket.Status)
	}

	assert.Nil(t, dynamicBucket) // dynamic bucket should not exist

	return bootstrapped
}

func deletionTestSuite(t *testing.T,
	deps *cositest.Dependencies,
) {
	t.Run("deletionPolicy=Retain", func(t *testing.T) {
		bootstrapped := deps.MustCopy() // copy prior test world state
		ctx := bootstrapped.ContextWithLogger
		r := claimReconcilerForClient(bootstrapped.Client)

		initClaim, initBucket := getClaimAndBucket(bootstrapped)
		require.NotNil(t, initBucket)

		initBucket.Spec.DeletionPolicy = cosiapi.BucketDeletionPolicyRetain
		require.NoError(t, r.Update(ctx, initBucket))

		require.NoError(t, r.Delete(ctx, initClaim))

		res, err := r.Reconcile(ctx, ctrl.Request{NamespacedName: cositest.NsName(&baseDynamicClaim)})
		assert.NoError(t, err)
		// assert.NotErrorIs(t, err, reconcile.TerminalError(nil))
		assert.Empty(t, res)

		bootstrapped.AssertResourceDoesNotExist(t, cositest.NsName(&baseDynamicClaim), &cosiapi.BucketClaim{})

		bucket := &cosiapi.Bucket{}
		require.NoError(t, r.Get(ctx, cositest.NsName(initBucket), bucket))

		require.NotNil(t, bucket)
		assert.Contains(t, bucket.GetAnnotations(), cosiapi.BucketClaimBeingDeletedAnnotation)
		assert.Equal(t, initBucket.Spec, bucket.Spec)
		assert.Equal(t, initBucket.Status, bucket.Status)
	})

	t.Run("deletionPolicy=Delete", func(t *testing.T) {
		bootstrapped := deps.MustCopy() // copy prior test world state
		ctx := bootstrapped.ContextWithLogger
		r := claimReconcilerForClient(bootstrapped.Client)

		initClaim, initBucket := getClaimAndBucket(bootstrapped)
		require.NotNil(t, initBucket)
		bucketHasFinalizer := len(initBucket.GetFinalizers()) > 0

		initBucket.Spec.DeletionPolicy = cosiapi.BucketDeletionPolicyDelete
		require.NoError(t, r.Update(ctx, initBucket))

		require.NoError(t, r.Delete(ctx, initClaim))

		res, err := r.Reconcile(ctx, ctrl.Request{NamespacedName: cositest.NsName(&baseDynamicClaim)})
		assert.NoError(t, err)
		assert.Empty(t, res)

		claim, bucket := getClaimAndBucket(bootstrapped)

		// claim waiting for Bucket deletion
		assert.Contains(t, claim.GetFinalizers(), cosiapi.ProtectionFinalizer)
		assert.Equal(t, initClaim.Spec, claim.Spec)
		assert.Equal(t, false, *claim.Status.ReadyToUse)
		assert.Nil(t, claim.Status.Error)
		assert.Equal(t, initClaim.Status.BoundBucketName, claim.Status.BoundBucketName)
		assert.Equal(t, initClaim.Status.Protocols, claim.Status.Protocols)

		if !bucketHasFinalizer {
			// If Bucket had no finalizer before deletion, Bucket will delete immediately.
			assert.Nil(t, bucket)
			return
		}

		require.NotNil(t, bucket)
		assert.Contains(t, bucket.GetAnnotations(), cosiapi.BucketClaimBeingDeletedAnnotation)
		assert.Contains(t, bucket.GetFinalizers(), cosiapi.ProtectionFinalizer)
		assert.NotZero(t, bucket.GetDeletionTimestamp())
		assert.Equal(t, initBucket.Spec, bucket.Spec)
		assert.Equal(t, initBucket.Status, bucket.Status)
	})
}

func deletionTestSuiteWithoutBucket(t *testing.T,
	deps *cositest.Dependencies,
) {
	bootstrapped := deps.MustCopy() // copy prior test world state
	ctx := bootstrapped.ContextWithLogger
	r := claimReconcilerForClient(bootstrapped.Client)

	initClaim, initBucket := getClaimAndBucket(bootstrapped)
	require.NotNil(t, initClaim)
	assert.Nil(t, initBucket) // bucket should not exist at start of this test deletionTestSuiteWithoutBucket

	require.NoError(t, r.Delete(ctx, initClaim))

	res, err := r.Reconcile(ctx, ctrl.Request{NamespacedName: cositest.NsName(&baseDynamicClaim)})
	assert.NoError(t, err)
	assert.Empty(t, res)

	bootstrapped.AssertResourceDoesNotExist(t, cositest.NsName(&baseDynamicClaim), &cosiapi.BucketClaim{})
	bootstrapped.AssertResourceDoesNotExist(t, cositest.BucketNsName(initClaim), &cosiapi.Bucket{})
}

func TestBucketClaimReconcile(t *testing.T) {
	// A lot of things can happen after successful initialization. Test all of them, building off of
	// successful initialization with subsequent tests.
	t.Run("successful initialization", func(t *testing.T) {
		type testDef struct {
			name            string
			testInitialFunc func(t *testing.T) *cositest.Dependencies
		}
		tests := []testDef{
			{
				name:            "dynamic provisioning",
				testInitialFunc: dynamicInitializationTest,
			},
			{
				name: "static provisioning (preset UID)",
				testInitialFunc: func(t *testing.T) *cositest.Dependencies {
					return staticInitializationTest(t, true)
				},
			},
			{
				name: "static provisioning (no preset UID)",
				testInitialFunc: func(t *testing.T) *cositest.Dependencies {
					return staticInitializationTest(t, false)
				},
			},
		}
		for _, test := range tests {
			t.Run(test.name, func(t *testing.T) {
				initBootstrapped := test.testInitialFunc(t)

				// ensure that subtests have bucket info on the claim
				_, initBucket := getClaimAndBucket(initBootstrapped)
				require.NotNil(t, initBucket)

				t.Run("reconcile again", func(t *testing.T) {
					bootstrapped := initBootstrapped.MustCopy() // copy prior test world state
					ctx := bootstrapped.ContextWithLogger
					r := claimReconcilerForClient(bootstrapped.Client)

					initClaim, initBucket := getClaimAndBucket(bootstrapped)
					require.NotNil(t, initBucket)

					res, err := r.Reconcile(ctx, ctrl.Request{NamespacedName: cositest.NsName(&baseDynamicClaim)})
					assert.NoError(t, err)
					assert.Empty(t, res)

					claim, bucket := getClaimAndBucket(bootstrapped)

					// claim should be unchanged since bucket is not ready
					assert.Equal(t, initClaim.Finalizers, claim.Finalizers)
					assert.Equal(t, initClaim.Spec, claim.Spec)
					assert.Equal(t, initClaim.Status, claim.Status)

					assert.Equal(t, initBucket.Spec, bucket.Spec)
					assert.Equal(t, initBucket.Status, bucket.Status)

					buckets := &cosiapi.BucketList{}
					assert.NoError(t, r.List(ctx, buckets))
					assert.Len(t, buckets.Items, 1) // no other bucket should be created
				})

				t.Run("clears stale status error while waiting on Bucket", func(t *testing.T) {
					bootstrapped := initBootstrapped.MustCopy() // copy prior test world state
					ctx := bootstrapped.ContextWithLogger
					r := claimReconcilerForClient(bootstrapped.Client)

					initClaim, _ := getClaimAndBucket(bootstrapped)
					initClaim.Status.Error = cosiapi.NewTimestampedError(
						time.Now(), "stale error left over from an earlier failed reconcile")
					require.NoError(t, r.Status().Update(ctx, initClaim))

					res, err := r.Reconcile(ctx, ctrl.Request{NamespacedName: cositest.NsName(&baseDynamicClaim)})
					assert.NoError(t, err)
					assert.Empty(t, res)

					claim, _ := getClaimAndBucket(bootstrapped)
					assert.Nil(t, claim.Status.Error)
					require.NotNil(t, claim.Status.ReadyToUse)
					assert.False(t, *claim.Status.ReadyToUse)
					assert.Equal(t, initClaim.Status.BoundBucketName, claim.Status.BoundBucketName)
				})

				t.Run("deletion before Bucket reconcile", func(t *testing.T) {
					deletionTestSuite(t, initBootstrapped)
				})

				t.Run("completion after Bucket ready", func(t *testing.T) {
					bootstrapped := initBootstrapped.MustCopy() // copy prior test world state
					ctx := bootstrapped.ContextWithLogger
					r := claimReconcilerForClient(bootstrapped.Client)

					initClaim, initBucket := getClaimAndBucket(bootstrapped)

					// Reconcile Bucket using sidecar logic
					initBucket, err := sidecartest.ReconcileOpinionatedS3Bucket(t, bootstrapped, cositest.NsName(initBucket))
					require.NoError(t, err)

					res, err := r.Reconcile(ctx, ctrl.Request{NamespacedName: cositest.NsName(&baseDynamicClaim)})
					assert.NoError(t, err)
					assert.Empty(t, res)

					claim, bucket := getClaimAndBucket(bootstrapped)

					assert.Equal(t, initClaim.Finalizers, claim.Finalizers)
					assert.Equal(t, initClaim.Spec, claim.Spec)
					assert.Equal(t, initClaim.Status.BoundBucketName, claim.Status.BoundBucketName) // still bound to same bucket
					assert.True(t, *claim.Status.ReadyToUse)
					assert.Equal(t, []cosiapi.ObjectProtocol{cosiapi.ObjectProtocolS3}, claim.Status.Protocols)
					assert.Nil(t, claim.Status.Error)

					assert.Equal(t, initBucket.Spec, bucket.Spec)
					assert.Equal(t, initBucket.Status, bucket.Status)

					buckets := &cosiapi.BucketList{}
					assert.NoError(t, r.List(ctx, buckets))
					assert.Len(t, buckets.Items, 1) // no other bucket should be created

					t.Run("subsequent deletion", func(t *testing.T) {
						deletionTestSuite(t, initBootstrapped)
					})
				})

				t.Run("not ready after Bucket ID generated but not provisioned", func(t *testing.T) {
					// The sidecar's DriverGenerateBucketId call persists status.bucketID before
					// any backend bucket exists. A set bucketID alone must not mark the claim
					// ready, since readyToUse is mirrored from the Bucket and is still false.

					// Set up: run the real sidecar Bucket reconciler against a driver that
					// implements DriverGenerateBucketId but fails DriverCreateBucket, so the
					// Bucket is left with an ID but unprovisioned by the production code path
					// rather than by the test writing status directly.
					bootstrapped := initBootstrapped.MustCopy() // copy prior test world state
					ctx := bootstrapped.ContextWithLogger
					r := claimReconcilerForClient(bootstrapped.Client)

					_, bucketToProvision := getClaimAndBucket(bootstrapped)
					idOnlyServer := cositest.FakeProvisionerServer{
						GenerateBucketIdFunc: sidecartest.OpinionatedGenerateBucketIdFunc,
						// nolint:lll
						CreateBucketFunc: func(ctx context.Context, dcbr *cosiproto.DriverCreateBucketRequest) (*cosiproto.DriverCreateBucketResponse, error) {
							return nil, status.Error(codes.Unavailable, "backend not ready")
						},
					}
					_, err := sidecartest.ReconcileBucket(t, bootstrapped, &idOnlyServer,
						sidecartest.OpinionatedS3DriverInfo(), cositest.NsName(bucketToProvision))
					require.Error(t, err) // DriverCreateBucket failed, so the Bucket never became ready

					initClaim, initBucket := getClaimAndBucket(bootstrapped)
					require.NotEmpty(t, initBucket.Status.BucketID) // DriverGenerateBucketId's ID was persisted
					require.False(t, ptr.Deref(initBucket.Status.ReadyToUse, false))

					// Act: reconcile the BucketClaim against that unprovisioned Bucket.
					res, err := r.Reconcile(ctx, ctrl.Request{NamespacedName: cositest.NsName(&baseDynamicClaim)})

					// Expect: success with no requeue. The claim mirrors the Bucket's (not ready)
					// status, and the Bucket watch re-enqueues the claim when readyToUse changes.
					assert.NoError(t, err)
					assert.Empty(t, res)

					// Validate: the claim is still bound and not ready, with no protocols, and
					// the controller did not write to the Bucket it doesn't own the status of.
					claim, bucket := getClaimAndBucket(bootstrapped)

					assert.Equal(t, initClaim.Spec, claim.Spec)
					assert.Equal(t, initClaim.Status.BoundBucketName, claim.Status.BoundBucketName)
					assert.False(t, ptr.Deref(claim.Status.ReadyToUse, false))
					assert.Empty(t, claim.Status.Protocols)

					// the sidecar owns the Bucket status; the controller must not touch it
					assert.Equal(t, initBucket.Status, bucket.Status)
				})

				t.Run("terminal error when ready Bucket has no ID", func(t *testing.T) {
					// readyToUse is set but bucketID is absent. A ready Bucket must have an ID, so this
					// is a driver bug that retrying won't fix.

					// Set up: fully provision the Bucket with the sidecar reconciler, then clear
					// status.bucketID.
					bootstrapped := initBootstrapped.MustCopy() // copy prior test world state
					ctx := bootstrapped.ContextWithLogger
					r := claimReconcilerForClient(bootstrapped.Client)

					_, bucketToProvision := getClaimAndBucket(bootstrapped)
					noIdBucket, err := sidecartest.ReconcileOpinionatedS3Bucket(
						t, bootstrapped, cositest.NsName(bucketToProvision))
					require.NoError(t, err)
					require.True(t, ptr.Deref(noIdBucket.Status.ReadyToUse, false))

					// clear the BucketID
					noIdBucket.Status.BucketID = ""
					require.NoError(t, bootstrapped.Client.Status().Update(ctx, noIdBucket))

					initClaim, initBucket := getClaimAndBucket(bootstrapped)
					require.Empty(t, initBucket.Status.BucketID)
					require.True(t, ptr.Deref(initBucket.Status.ReadyToUse, false))

					// Act: reconcile the BucketClaim against that Bucket.
					res, err := r.Reconcile(ctx, ctrl.Request{NamespacedName: cositest.NsName(&baseDynamicClaim)})

					// Expect: terminal error, so the reconciler does not retry with backoff.
					assert.Error(t, err)
					assert.ErrorIs(t, err, reconcile.TerminalError(nil))
					assert.Empty(t, res)

					// Validate: the claim never became ready, and the controller did not write to
					// the Bucket it doesn't own the status of.
					claim, bucket := getClaimAndBucket(bootstrapped)

					assert.Equal(t, initClaim.Spec, claim.Spec)
					assert.Equal(t, initClaim.Status.BoundBucketName, claim.Status.BoundBucketName)
					assert.False(t, ptr.Deref(claim.Status.ReadyToUse, false))
					assert.Empty(t, claim.Status.Protocols)

					// the sidecar owns the Bucket status; the controller must not touch it
					assert.Equal(t, initBucket.Status, bucket.Status)
				})

				t.Run("still waiting after Bucket error", func(t *testing.T) {
					bootstrapped := initBootstrapped.MustCopy() // copy prior test world state
					ctx := bootstrapped.ContextWithLogger
					r := claimReconcilerForClient(bootstrapped.Client)

					// make Bucket incompatible with Sidecar reconciler so it errors
					_, errBucket := getClaimAndBucket(bootstrapped)
					errBucket.Spec.Protocols = []cosiapi.ObjectProtocol{cosiapi.ObjectProtocolGcs}
					require.NoError(t, bootstrapped.Client.Update(ctx, errBucket))

					// Reconcile Bucket using sidecar logic
					_, err := sidecartest.ReconcileOpinionatedS3Bucket(t, bootstrapped, cositest.NsName(errBucket))
					require.Error(t, err)

					initClaim, initBucket := getClaimAndBucket(bootstrapped)

					res, err := r.Reconcile(ctx, ctrl.Request{NamespacedName: cositest.NsName(&baseDynamicClaim)})
					assert.NoError(t, err)
					assert.Empty(t, res)

					claim, bucket := getClaimAndBucket(bootstrapped)

					// claim should be unchanged since bucket is not ready
					assert.Equal(t, initClaim.Finalizers, claim.Finalizers)
					assert.Equal(t, initClaim.Spec, claim.Spec)
					assert.Equal(t, initClaim.Status, claim.Status)

					assert.Equal(t, initBucket.Spec, bucket.Spec)
					assert.Equal(t, initBucket.Status, bucket.Status)

					buckets := &cosiapi.BucketList{}
					assert.NoError(t, r.List(ctx, buckets))
					assert.Len(t, buckets.Items, 1) // no other bucket should be created

					t.Run("subsequent deletion", func(t *testing.T) {
						deletionTestSuite(t, initBootstrapped)
					})
				})

				t.Run("bucket deleted before claim", func(t *testing.T) {
					bootstrapped := initBootstrapped.MustCopy() // copy prior test world state
					ctx := bootstrapped.ContextWithLogger
					r := claimReconcilerForClient(bootstrapped.Client)

					_, initBucket := getClaimAndBucket(bootstrapped)
					require.NotNil(t, initBucket)

					// Add the protection finalizer as the Sidecar would, so the Bucket lingers in
					// a deleting state instead of disappearing immediately.
					initBucket.Finalizers = append(initBucket.Finalizers, cosiapi.ProtectionFinalizer)
					require.NoError(t, r.Update(ctx, initBucket))
					require.NoError(t, r.Delete(ctx, initBucket)) // delete Bucket before BucketClaim

					// Deleting the claim afterwards must behave the same as the normal orderings.
					// Notably, the Bucket still has to be annotated, or the Sidecar will never
					// release it and both resources stay stuck.
					deletionTestSuite(t, bootstrapped)
				})

				t.Run("err bucket force-deleted", func(t *testing.T) {
					// note: this is also equivalent to the BucketClaim `boundBucketName` not
					// matching the previous/intended bucket.

					bootstrapped := initBootstrapped.MustCopy() // copy prior test world state
					ctx := bootstrapped.ContextWithLogger
					r := claimReconcilerForClient(bootstrapped.Client)

					initClaim, initBucket := getClaimAndBucket(bootstrapped)
					require.NoError(t, r.Delete(ctx, initBucket)) // simulate force-delete of bucket while claim is bound

					res, err := r.Reconcile(ctx, ctrl.Request{NamespacedName: cositest.NsName(&baseDynamicClaim)})
					assert.Error(t, err) // TODO: should be NoError when Bucket watcher is set up
					assert.ErrorIs(t, err, reconcile.TerminalError(nil))
					assert.ErrorContains(t, err, "unrecoverable degradation")
					assert.ErrorContains(t, err, "no longer exists")
					assert.Empty(t, res)

					claim, _ := getClaimAndBucket(bootstrapped)
					assert.Contains(t, claim.GetFinalizers(), cosiapi.ProtectionFinalizer)
					assert.Equal(t, initClaim.Spec, claim.Spec)
					assert.False(t, *claim.Status.ReadyToUse)
					assert.Equal(t, initClaim.Status.BoundBucketName, claim.Status.BoundBucketName) // still bound to missing bucket
					assert.Equal(t, initClaim.Status.Protocols, claim.Status.Protocols)
					require.NotNil(t, claim.Status.Error)
					assert.Contains(t, *claim.Status.Error.Message, "unrecoverable degradation")

					buckets := &cosiapi.BucketList{}
					require.NoError(t, r.List(ctx, buckets))
					assert.Len(t, buckets.Items, 0) // no buckets should be created when claim is degraded

					t.Run("subsequent deletion", func(t *testing.T) {
						deletionTestSuite(t, initBootstrapped)
					})
				})
			})
		}
	})

	t.Run("dynamic provisioning", func(t *testing.T) {
		t.Run("bucketclass does not exist", func(t *testing.T) {
			bootstrapped := cositest.MustBootstrap(t,
				baseDynamicClaim.DeepCopy(),
				// no bucketclass
			)
			r := controller.BucketClaimReconciler{
				Client: bootstrapped.Client,
				Scheme: bootstrapped.Client.Scheme(),
			}
			ctx := bootstrapped.ContextWithLogger

			res, err := r.Reconcile(ctx, ctrl.Request{NamespacedName: cositest.NsName(&baseDynamicClaim)})
			assert.Error(t, err)
			assert.NotErrorIs(t, err, reconcile.TerminalError(nil)) // should be terminal error when bucketclass watcher is set up
			assert.Empty(t, res)

			claim, _, _ := getAllClaimResources(bootstrapped)

			assert.Contains(t, claim.GetFinalizers(), cosiapi.ProtectionFinalizer)
			status := claim.Status
			assert.Empty(t, status.BoundBucketName)
			assert.Equal(t, false, *status.ReadyToUse)
			assert.Empty(t, status.Protocols)
			serr := status.Error
			require.NotNil(t, serr)
			assert.NotNil(t, serr.Time)
			assert.NotNil(t, serr.Message)
			assert.Contains(t, *serr.Message, baseBucketClass.Name)

			bootstrapped.AssertResourceDoesNotExist(t, types.NamespacedName{Name: "bc-dynamicuid"}, &cosiapi.Bucket{})

			t.Run("subsequent deletion", func(t *testing.T) {
				deletionTestSuiteWithoutBucket(t, bootstrapped)
			})
		})
	})

	t.Run("static provisioning", func(t *testing.T) {
		t.Run("bucket does not exist", func(t *testing.T) {
			bootstrapped := cositest.MustBootstrap(t,
				baseStaticClaim.DeepCopy(),
				// no bucket
			)
			r := controller.BucketClaimReconciler{
				Client: bootstrapped.Client,
				Scheme: bootstrapped.Client.Scheme(),
			}
			ctx := bootstrapped.ContextWithLogger

			res, err := r.Reconcile(ctx, ctrl.Request{NamespacedName: cositest.NsName(&baseStaticClaim)})
			assert.NoError(t, err) // not an error: the Bucket watch re-enqueues once it's created
			assert.Empty(t, res)

			claim, _, _ := getAllClaimResources(bootstrapped)

			assert.Contains(t, claim.GetFinalizers(), cosiapi.ProtectionFinalizer)
			assert.Equal(t, baseStaticClaim.Spec, claim.Spec)
			assert.Nil(t, claim.Status.Error)
			assert.Nil(t, claim.Status.ReadyToUse)
			assert.Empty(t, claim.Status.BoundBucketName)
			assert.Empty(t, claim.Status.Protocols)

			buckets := &cosiapi.BucketList{}
			assert.NoError(t, r.List(ctx, buckets))
			assert.Len(t, buckets.Items, 0) // no bucket should be created

			t.Run("subsequent deletion", func(t *testing.T) {
				deletionTestSuiteWithoutBucket(t, bootstrapped)
			})
		})

		t.Run("bucket does not exist, with stale status error", func(t *testing.T) {
			bootstrapped := cositest.MustBootstrap(t,
				baseStaticClaim.DeepCopy(),
				// no bucket
			)
			r := claimReconcilerForClient(bootstrapped.Client)
			ctx := bootstrapped.ContextWithLogger

			claim := &cosiapi.BucketClaim{}
			require.NoError(t, r.Get(ctx, cositest.NsName(&baseStaticClaim), claim))
			claim.Status.Error = cosiapi.NewTimestampedError(
				time.Now(), "stale error left over from an earlier failed reconcile")
			require.NoError(t, r.Status().Update(ctx, claim))

			res, err := r.Reconcile(ctx, ctrl.Request{NamespacedName: cositest.NsName(&baseStaticClaim)})
			assert.NoError(t, err) // not an error: the Bucket watch re-enqueues once it's created
			assert.Empty(t, res)

			claim, _, _ = getAllClaimResources(bootstrapped)

			assert.Contains(t, claim.GetFinalizers(), cosiapi.ProtectionFinalizer)
			assert.Nil(t, claim.Status.Error)
			// readyToUse is a required status field, so clearing the stale error must write it too.
			require.NotNil(t, claim.Status.ReadyToUse)
			assert.False(t, *claim.Status.ReadyToUse)
			assert.Empty(t, claim.Status.BoundBucketName)
		})

		t.Run("bucket created after initial reconcile", func(t *testing.T) {
			bootstrapped := cositest.MustBootstrap(t,
				baseStaticClaim.DeepCopy(),
				// no bucket
			)
			r := claimReconcilerForClient(bootstrapped.Client)
			ctx := bootstrapped.ContextWithLogger

			res, err := r.Reconcile(ctx, ctrl.Request{NamespacedName: cositest.NsName(&baseStaticClaim)})
			require.NoError(t, err) // not an error: the Bucket watch re-enqueues once it's created
			assert.Empty(t, res)

			require.NoError(t, bootstrapped.Client.Create(ctx, baseStaticBucket.DeepCopy()))

			bucket, err := sidecartest.ReconcileOpinionatedS3Bucket(
				t,
				bootstrapped,
				cositest.NsName(&baseStaticBucket),
			)
			require.NoError(t, err)
			require.NotNil(t, bucket.Status.ReadyToUse)
			require.True(t, *bucket.Status.ReadyToUse)

			res, err = r.Reconcile(ctx, ctrl.Request{NamespacedName: cositest.NsName(&baseStaticClaim)})
			assert.NoError(t, err)
			assert.Empty(t, res)

			claim, dynamicBucket, staticBucket := getAllClaimResources(bootstrapped)

			require.NotNil(t, claim)
			assert.Contains(t, claim.GetFinalizers(), cosiapi.ProtectionFinalizer)
			assert.Equal(t, "static-bucket", claim.Status.BoundBucketName)
			assert.Equal(t, bucket.Status.ReadyToUse, claim.Status.ReadyToUse)
			assert.Equal(t, bucket.Status.Protocols, claim.Status.Protocols)
			assert.Nil(t, claim.Status.Error)

			assert.Nil(t, dynamicBucket)
			assert.Equal(t, bucket.Status, staticBucket.Status)
		})

		t.Run("bucket bucketClaimRef mismatch", func(t *testing.T) {
			type bucketClaimRefMismatchTest struct {
				testName      string
				bucketRef     cosiapi.BucketClaimReference
				errorContains []string
			}
			tests := []bucketClaimRefMismatchTest{
				{
					"namespace mismatch",
					cosiapi.BucketClaimReference{
						Namespace: "other-namespace",
						Name:      baseStaticClaim.Name,
						UID:       "",
					},
					[]string{"namespace", "other-namespace"},
				},
				{
					"name mismatch",
					cosiapi.BucketClaimReference{
						Namespace: baseStaticClaim.Namespace,
						Name:      "other-claim-name",
						UID:       "",
					},
					[]string{"name", "other-claim-name"},
				},
				{
					"UID mismatch", // already bound to different claim
					cosiapi.BucketClaimReference{
						Namespace: baseStaticClaim.Namespace,
						Name:      baseStaticClaim.Name,
						UID:       types.UID("other-uid"),
					},
					[]string{"Bucket claim ref UID", "other-uid"},
				},
			}
			for _, tt := range tests {
				t.Run(tt.testName, func(t *testing.T) {
					bucketNoMatch := baseStaticBucket.DeepCopy()
					bucketNoMatch.Spec.BucketClaimRef = tt.bucketRef
					bootstrapped := cositest.MustBootstrap(t,
						baseStaticClaim.DeepCopy(),
						bucketNoMatch,
					)
					r := controller.BucketClaimReconciler{
						Client: bootstrapped.Client,
						Scheme: bootstrapped.Client.Scheme(),
					}
					ctx := bootstrapped.ContextWithLogger

					res, err := r.Reconcile(ctx, ctrl.Request{NamespacedName: cositest.NsName(&baseStaticClaim)})
					assert.Error(t, err)
					assert.ErrorIs(t, err, reconcile.TerminalError(nil))
					for _, s := range tt.errorContains {
						assert.ErrorContains(t, err, s)
					}
					assert.Empty(t, res)

					claim, dynamicBucket, staticBucket := getAllClaimResources(bootstrapped)

					assert.Contains(t, claim.GetFinalizers(), cosiapi.ProtectionFinalizer)
					assert.Equal(t, baseStaticClaim.Spec, claim.Spec)
					require.NotNil(t, claim.Status.Error)
					assert.NotNil(t, claim.Status.Error.Time)
					assert.NotNil(t, claim.Status.Error.Message)
					for _, s := range tt.errorContains {
						assert.Contains(t, *claim.Status.Error.Message, s)
					}
					assert.False(t, ptr.Deref(claim.Status.ReadyToUse, true))
					assert.Empty(t, claim.Status.BoundBucketName)
					assert.Empty(t, claim.Status.Protocols)

					assert.Equal(t, bucketNoMatch, staticBucket)

					assert.Nil(t, dynamicBucket) // no dynamic bucket

					t.Run("subsequent deletion", func(t *testing.T) {
						bootstrapped := bootstrapped.MustCopy() // copy prior test world state
						ctx := bootstrapped.ContextWithLogger
						r := claimReconcilerForClient(bootstrapped.Client)

						initClaim, initBucket := getClaimAndBucket(bootstrapped)
						require.NotNil(t, initClaim)
						require.NotNil(t, initBucket)

						require.NoError(t, r.Delete(ctx, initClaim))

						res, err := r.Reconcile(ctx, ctrl.Request{NamespacedName: cositest.NsName(&baseDynamicClaim)})
						assert.NoError(t, err)
						assert.Empty(t, res)

						bootstrapped.AssertResourceDoesNotExist(t, cositest.NsName(&baseDynamicClaim), &cosiapi.BucketClaim{})

						bucket := &cosiapi.Bucket{}
						require.NoError(t, r.Get(ctx, cositest.NsName(initBucket), bucket))
						assert.Equal(t, initBucket, bucket) // bucket unchanged since not matched to claim
					})
				})
			}
		})
	})
}
